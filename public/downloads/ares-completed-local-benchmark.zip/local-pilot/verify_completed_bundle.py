"""Portable stdlib-only audit of the completed benchmark evidence archive."""
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / 'manifest.json').read_text())
for name, info in manifest['files'].items():
    data = (ROOT / name).read_bytes()
    assert len(data) == info['bytes'], name
    assert hashlib.sha256(data).hexdigest() == info['sha256'], name

outcomes = {}
for run, trial_paths in manifest['trial_sets'].items():
    spec = importlib.util.spec_from_file_location('bundle_oracle', ROOT / 'runs' / run / 'frozen-harness/pilot_grade.py')
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    rows = []
    for name in trial_paths:
        trial = json.loads((ROOT / name).read_text())
        result = trial.get('agent_result') or {}
        error = trial.get('failure') or result.get('error')
        if result.get('completed') is False or result.get('partial') is True:
            error = error or {'agent_completion_state': 'blocked_or_partial'}
        replay = oracle.grade(trial['spec'], trial['fixture'], result.get('final_response'),
                              runtime_error=error, messages=result.get('messages'))
        if not trial['scheduled_provider_calls'] or not any(e['returned'] for e in trial['call_observer']):
            replay['passed'] = False
            replay['failed_checks'].append('no_observed_returned_provider_execution')
        assert replay == trial['grade'], name
        rows.append(bool(replay['passed']))
    outcomes[run] = {'attempted':len(rows),'passed':sum(rows),'failed_or_blocked':sum(not x for x in rows)}
assert outcomes['local-tool-pilot-001'] == {'attempted':6,'passed':0,'failed_or_blocked':6}
assert outcomes['local-tool-followup-001'] == {'attempted':1,'passed':1,'failed_or_blocked':0}
assert outcomes['local-tool-pilot-002'] == {'attempted':6,'passed':6,'failed_or_blocked':0}
result = json.loads((ROOT / 'runs/local-tool-pilot-002/completion-result.json').read_text())
assert result['local_benchmark_complete'] and result['passed'] == 6
assert result['reported_accepted_calls'] == result['scheduled_canonical_dispatches'] == 34
assert result['not_official_deeprsi'] and not result['broader_capability_programme_complete']
assert result['public_review']['execution_artifacts_verified']
assert result['public_review']['controller_semantic_review_complete']
assert result['public_review']['outcome'] == 'ACCEPT_SCOPED_CLAIMS'
assert result['evaluator_validation'] == {'tests':19,'failures':0,'errors':0,'skipped':0}
print(json.dumps({'bundle_verified':True,'file_count':len(manifest['files']),
                  'trial_sets_replayed_separately':outcomes,
                  'current_local_benchmark_complete':True,'current_score':'6/6',
                  'official_deeprsi_score':False,'model_calls_made_by_verification':0},indent=2))
