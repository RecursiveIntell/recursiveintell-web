"""Package completed score plus immutable failure history and audit the ZIP."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path('/home/sikmindz/work/ares-benchmark-program')
RUN = ROOT / 'runs/local-tool-pilot-002'
PACK = ROOT / 'runs/completed-local-benchmark-bundle-001'
REVIEW = ROOT / 'reviews/completed-pilot-public-001'
PRIVATE_KEYS = {'reasoning','reasoning_content','thinking','analysis','reasoning_details',
                'codex_reasoning_items','api_key','access_token','refresh_token'}


def load(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, obj):
    with p.open('x') as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write('\n')


def main():
    result = load(RUN / 'completion-result.json')
    review = load(RUN / 'public-review-integration.json')
    report = ROOT / 'COMPLETED-LOCAL-BENCHMARK.md'
    assert result['local_benchmark_complete'] and result['passed'] == 6
    assert review['controller_semantic_review_complete'] and review['outcome'] == 'ACCEPT_SCOPED_CLAIMS'
    assert review['report_sha256'] == sha(report)
    PACK.mkdir(exist_ok=False)
    sources = [report, ROOT / 'authorization-completion-001.json',
               ROOT / 'authorization-20261014.json', ROOT / 'authorization-pilot-larger-20261014.json',
               ROOT / 'LOCAL-MODEL-RESULTS.md', ROOT / 'benchmark.py']
    run_names = ['local-tool-pilot-001','local-tool-followup-001','local-tool-pilot-002']
    for name in run_names:
        sources += [p for p in (ROOT/'runs'/name).rglob('*') if p.is_file()
                    and p.suffix in {'.json','.py','.log'} and '__pycache__' not in p.parts]
    sources += [p for p in (ROOT/'runs/local-model-closeout-002').glob('*.json')]
    sources += [REVIEW/'panel.json',REVIEW/'verification.json',
                REVIEW/'profiles/public.stdout.txt',REVIEW/'profiles/public.stderr.txt']
    for name in ['verify_pilot.py','verify_completed_pilot.py','record_completed_pilot.py',
                 'verify_completed_bundle.py','build_completed_bundle.py','observer-tests-004.xml']:
        sources.append(ROOT / 'local-pilot' / name)
    removed = []
    projections = []
    def clean(v, path=''):
        if isinstance(v,dict):
            obj = {}
            for k,x in v.items():
                if k in PRIVATE_KEYS:
                    removed.append(path+'/'+k)
                else:
                    obj[k] = clean(x,path+'/'+k)
            return obj
        if isinstance(v,list): return [clean(x,path+'/'+str(i)) for i,x in enumerate(v)]
        return v
    seen = set()
    for source in sources:
        name = str(source.relative_to(ROOT))
        if name in seen: continue
        seen.add(name)
        target = PACK / name
        target.parent.mkdir(parents=True,exist_ok=True)
        if source.suffix == '.json':
            removed = []
            value = clean(load(source))
            if removed:
                save(target,value)
                projections.append({'path':name,'original_sha256':sha(source),
                    'projection_sha256':sha(target),'removed_private_field_paths':removed,
                    'projection_is_not_raw_source':True})
            else: shutil.copy2(source,target)
        else: shutil.copy2(source,target)
    shutil.copy2(ROOT/'local-pilot/verify_completed_bundle.py',PACK/'verify_bundle.py')
    with (PACK/'START-HERE.md').open('x') as f:
        f.write('# Completed local benchmark evidence\n\n'
            'Current result: **local-tool-pilot-002, 6/6 passed**. Read COMPLETED-LOCAL-BENCHMARK.md.\n\n'
            'The original six-case run is preserved as measurement-invalid; the one-case recovery diagnostic is separate. '
            'Neither is pooled with the current score. LOCAL-MODEL-RESULTS.md is a historical partial report, not current status.\n\n'
            'Run `python3 -P verify_bundle.py` from this directory for offline hash checks and separate frozen-grader replay '
            'of all three recorded attempts. It makes no model calls. Session databases, credentials and private reasoning are excluded; '
            'any filtered JSON has explicit original/projection digest lineage.\n\n'
            'This is not an official DeepRSI score or a completed broad capability programme.\n')
    save(PACK/'projection-lineage.json',projections)
    files = {str(p.relative_to(PACK)):{'bytes':p.stat().st_size,'sha256':sha(p)}
             for p in PACK.rglob('*') if p.is_file()}
    trial_sets = {}
    for name in run_names:
        paths = sorted(str(p.relative_to(PACK)) for p in (PACK/'runs'/name).glob('*/trial.json'))
        trial_sets[name] = paths
    assert [len(trial_sets[n]) for n in run_names] == [6,1,6]
    save(PACK/'manifest.json',{'schema':'AresCompletedLocalBenchmarkBundleManifestV1',
        'created_at':datetime.now(timezone.utc).isoformat(),'files':files,'trial_sets':trial_sets,
        'current_scored_run':'local-tool-pilot-002','historical_attempts_not_pooled':True,
        'private_session_databases_excluded':True,'not_official_deeprsi':True})
    tested = subprocess.run([sys.executable,'-P',str(PACK/'verify_bundle.py')],
                            capture_output=True,text=True,check=False)
    assert tested.returncode == 0, tested.stderr
    offline = json.loads(tested.stdout)
    archive = ROOT / 'ares-completed-local-benchmark.zip'
    assert not archive.exists()
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(PACK.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:
                z.write(p,str(p.relative_to(PACK)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        names = z.namelist()
        assert len(names) == len(set(names)) == len(files)+1
        for name,info in files.items():
            data = z.read(name)
            assert len(data) == info['bytes'] and hashlib.sha256(data).hexdigest() == info['sha256']
        assert not any(n.endswith(('.db','.db-wal','.db-shm')) for n in names)
        for name in names:
            if name.endswith('.json'):
                removed = []
                clean(json.loads(z.read(name)))
                assert not removed, name
    receipt = {'schema':'AresCompletedLocalBenchmarkDeliverableVerificationV1',
        'verified_at':datetime.now(timezone.utc).isoformat(),'verified':True,
        'local_benchmark_complete':True,'passed':6,'failed_or_blocked':0,
        'archive':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
        'archive_file_count':len(names),'archive_crc_and_manifest_hashes_verified':True,
        'private_fields_removed_with_lineage':len(projections),'private_databases_excluded':True,
        'standalone_offline_verification':offline,'public_review_mechanically_and_semantically_verified':True,
        'report_sha256':sha(report),'result_sha256':sha(RUN/'completion-result.json'),
        'earlier_failed_attempts_preserved':True,'not_official_deeprsi':True,
        'broader_capability_programme_complete':False,'no_email_purchase_or_publication':True}
    save(RUN/'deliverable-verification.json',receipt)
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':
    main()
