"""Sequential bounded controller for the registered actual-model local pilot."""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid

ROOT=Path(__file__).resolve().parent
WORKSPACE=ROOT.parent
SOURCE=Path('/home/sikmindz/.ares/runtime/releases/56caa3efc0854a527b125ba34c964ebce437b8ad/source')
sys.path.insert(0,str(WORKSPACE))
sys.path.insert(1,str(ROOT))
from benchmark import run_owned,write_json,hash_paths
from pilot_fixtures import case_spec


def collect_fingerprint(source):
    # This pilot consumes tracked runtime source, not pytest's duration cache.
    revision=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
    dirty=subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=all'],text=True)
    if dirty.strip(): raise ValueError('SELECTED_RUNTIME_DIRTY')
    paths=subprocess.check_output(['git','-C',str(source),'ls-files','-z']).decode().split('\0')
    manifest=hash_paths(source,[p for p in paths if p])
    digest=hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return {'revision':revision,'tracked_file_count':len(manifest),
            'tracked_manifest_sha256':digest,'tracked_manifest':manifest}


def execute(name,admit_only=False,trial_call_limit=5):
    if type(trial_call_limit) is not int or not 1 <= trial_call_limit <= 16:
        raise ValueError("INVALID_TRIAL_CALL_LIMIT")
    total_call_limit=6*trial_call_limit
    if not name or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in name):
        raise ValueError('INVALID_RUN_NAME')
    run=WORKSPACE/'runs'/name
    run.mkdir(parents=True,exist_ok=False)
    before=collect_fingerprint(SOURCE)
    if before['revision']!='56caa3efc0854a527b125ba34c964ebce437b8ad': raise ValueError('SOURCE_IDENTITY_CHANGED')
    write_json(run/'source-before.json',before)
    frozen=run/'frozen-harness'; frozen.mkdir()
    hashes={}
    for file in ['pilot_controller.py','pilot_worker.py','pilot_fixtures.py','pilot_grade.py','test_pilot.py','test_counter_followup.py']:
        shutil.copy2(ROOT/file,frozen/file)
        hashes[file]=hashlib.sha256((ROOT/file).read_bytes()).hexdigest()
    write_json(run/'harness-before.json',hashes)
    protocol={'schema':'AresLocalControlledToolPilotProtocolV1','official_deeprsi':False,
              'source_revision':before['revision'],'model':'gpt-6-luna','provider':'openai-codex',
              'api_mode':'codex_responses','reasoning_effort':'high','memory_and_identity_loading':False,
              'fixture_tools':['bench_read','bench_apply'],
              'permitted_model_surface':['bench_read/bench_apply directly or the stock deferred tool_search/tool_describe/tool_call bridge'],
              'deferred_scope_gate':'raw effective catalog must be exactly the two fixture tools and an inert outside-catalog canary must be denied',
              'case_families':['atomic','recovery','scope'],
              'instances_per_family':2,'trial_call_limit':trial_call_limit,'total_trial_call_limit':total_call_limit,
              'trial_hard_wall_seconds':300,'controller_hard_wall_seconds':2100,
              'concurrent_trials':1,'admission_only':admit_only,
              'limitations':['Small diagnostic pilot, not a reliability rate or superiority claim',
                             'No official task pack/private grader; no DeepRSI score',
                             'Controlled tool loop, not whole runtime/as-shipped capability',
                             'No native Codex tool loop, memory, learning or long-horizon recovery exercise',
                             'SDK-internal retries are not independently wire-counted'],
              'graded_pass_requires':'Independent exact state, action ordering/identity/scope, and final-JSON agreement'}
    protocol['counter_policy']='single canonical codex nonstreaming seam; streaming delegates unwrapped'
    protocol['previous_attempts_not_pooled']=['local-tool-pilot-001','local-tool-followup-001']
    if trial_call_limit>5:
        authorization=WORKSPACE/'authorization-completion-001.json'
        document=json.loads(authorization.read_text())
        if document.get('operator_call_ceiling','missing') is not None:
            raise ValueError('COMPLETION_AUTHORIZATION_NOT_REGISTERED')
        protocol['completion_authorization_path']=str(authorization)
        protocol['completion_authorization_sha256']=hashlib.sha256(authorization.read_bytes()).hexdigest()
        protocol['scheduling_limit_is_controller_containment_not_operator_cap']=True
    write_json(run/'protocol.json',protocol)
    specs=[]
    for family in protocol['case_families']:
        for variant in range(2):
            case_id=family+'-'+str(variant+1)+'-'+uuid.uuid4().hex[:12]
            spec=case_spec(family,variant,case_id)
            write_json(run/(case_id+'-spec.json'),spec)
            specs.append((case_id,spec))
    write_json(run/'registered-cases.json',[{'case_id':i,'spec':s} for i,s in specs])
    env={'HOME':'/home/sikmindz','HERMES_HOME':'/home/sikmindz/.ares',
         'PATH':str(SOURCE/'.venv/bin')+':/usr/bin:/bin',
         'PYTHONPATH':str(SOURCE)+':'+str(ROOT)+':'+str(WORKSPACE),
         'PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','LANG':'C.UTF-8','TZ':'UTC'}
    started=time.monotonic(); results=[]; consumed=0
    for index,(case_id,spec) in enumerate(specs[:1] if admit_only else specs):
        remaining=2100-(time.monotonic()-started)
        if remaining<=0:
            results.append({'case_id':case_id,'status':'blocked_controller_wall_budget','passed':False}); continue
        output=run/case_id
        command=[str(SOURCE/'.venv/bin/python'),'-P',str(ROOT/'pilot_worker.py'),
                 '--spec',str(run/(case_id+'-spec.json')),'--output',str(output),
                 '--call-limit',str(trial_call_limit)]
        if admit_only: command+=['--admission-only']
        process=run_owned(command,ROOT,env,run/('worker-'+str(index)),min(300,remaining))
        write_json(run/('worker-'+str(index)+'-controller.json'),process)
        row={'case_id':case_id,'family':spec['family'],'variant':spec['variant'],
             'process_exit_code':process['exit_code'],'timed_out':process['timed_out'],
             'process_group_clean':process['process_group_clean'],'passed':False}
        artifact=output/'trial.json'
        if artifact.is_file():
            trial=json.loads(artifact.read_text()); used=trial['scheduled_provider_calls']; consumed+=used
            if used>trial_call_limit or consumed>total_call_limit: raise RuntimeError('CALL_BUDGET_VIOLATION')
            row.update(status=trial['status'],scheduled_provider_calls=used,
                       agent_usage=trial.get('agent_usage'),grade=trial.get('grade'),failure=trial.get('failure'))
            if not admit_only:
                row['passed']=(bool(trial.get('grade',{}).get('passed')) and trial['inputs_unchanged']
                               and process['exit_code']==0 and not process['timed_out']
                               and process['process_group_clean'])
            else:
                row['admitted']=(trial['status']=='passed_local_tool_and_route_admission'
                                 and process['exit_code']==0 and process['process_group_clean'])
        else: row['status']='missing_trial_artifact'
        results.append(row)
        print(json.dumps(row),flush=True)
    after=collect_fingerprint(SOURCE)
    write_json(run/'source-after.json',after)
    current={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in hashes}
    write_json(run/'harness-after.json',current)
    summary={'schema':'AresLocalControlledToolPilotSummaryV1','results':results,
             'admission_only':admit_only,'registered_trial_count':len(specs),
             'executed_record_count':len(results),'passed_trials':sum(r['passed'] for r in results),
             'failed_or_blocked_trials':sum(not r['passed'] for r in results),
             'scheduled_provider_calls':consumed,'source_unchanged':before==after,
             'harness_unchanged':hashes==current,'wall_seconds':time.monotonic()-started,
             'completed_at':datetime.now(timezone.utc).isoformat(),
             'official_deeprsi_complete':False,'full_capability_programme_complete':False,
             'registered_local_pilot_exercised':not admit_only and len(results)==len(specs)}
    write_json(run/'summary.json',summary)
    print(json.dumps(summary,indent=2),flush=True)
    intact=summary['source_unchanged'] and summary['harness_unchanged'] and all(r['process_group_clean'] for r in results)
    if admit_only:
        return 0 if intact and len(results)==1 and results[0].get('admitted') is True else 1
    return 0 if intact else 1


if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--run-name',required=True)
    parser.add_argument('--admission-only',action='store_true')
    parser.add_argument('--trial-call-limit',type=int,default=5)
    args=parser.parse_args()
    raise SystemExit(execute(args.run_name,args.admission_only,args.trial_call_limit))
