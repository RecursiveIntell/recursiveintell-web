"""Synthetic observer checks using the installed Codex streaming forwarder."""
from types import SimpleNamespace
import pytest
from pilot_worker import CallBudget, BudgetStop, instrument_codex_calls
from agent.chat_completion_helpers import interruptible_streaming_api_call


def make_agent(monkeypatch):
    import agent.chat_completion_helpers as helpers
    import ares_runtime.continuity.runtime as continuity
    monkeypatch.setattr(helpers, 'should_use_direct_api_call', lambda agent: False)
    monkeypatch.setattr(continuity, 'validate_context_dispatch_source', lambda *args: None)
    dispatched = []
    response = SimpleNamespace(model='gpt-6-luna', choices=[])
    agent = SimpleNamespace(api_mode='codex_responses', _interrupt_requested=False)
    def canonical(request):
        dispatched.append(request)
        return response
    agent._interruptible_api_call = canonical
    return agent, dispatched, response


def test_installed_stream_forwarder_counts_once_and_preserves_request(monkeypatch):
    agent, dispatched, response = make_agent(monkeypatch)
    budget = CallBudget(limit=2)
    instrument_codex_calls(agent, budget)
    request = {'model': 'gpt-6-luna', 'messages': [{'role': 'user', 'content': 'fixture'}]}
    assert interruptible_streaming_api_call(agent, request) is response
    assert len(budget.records) == 1
    assert dispatched == [request] and dispatched[0] is request
    assert budget.records[0]['returned'] is True
    assert agent._codex_on_first_delta is None


def test_stream_forwarder_denies_next_dispatch_at_exact_limit(monkeypatch):
    agent, dispatched, _ = make_agent(monkeypatch)
    budget = CallBudget(limit=1)
    instrument_codex_calls(agent, budget)
    request = {'model': 'gpt-6-luna'}
    interruptible_streaming_api_call(agent, request)
    with pytest.raises(BudgetStop):
        interruptible_streaming_api_call(agent, request)
    assert len(dispatched) == len(budget.records) == 1


def test_observer_refuses_unqualified_route_before_dispatch():
    agent = SimpleNamespace(api_mode='chat_completions')
    with pytest.raises(BudgetStop):
        instrument_codex_calls(agent, CallBudget())


def test_receipts_omit_private_reasoning_and_credential_fields():
    from pilot_worker import clean
    value = {'final_response': '{"outcome":"confirmed"}',
             'messages': [{'role': 'assistant', 'content': 'public final',
                           'codex_reasoning_items': ['private fixture'],
                           'reasoning_details': {'private': True},
                           'reasoning_content': 'private fixture'}],
             'access_token': 'private fixture'}
    assert clean(value) == {'final_response': '{"outcome":"confirmed"}',
                            'messages': [{'role': 'assistant', 'content': 'public final'}]}
