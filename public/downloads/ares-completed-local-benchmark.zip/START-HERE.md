# Completed local benchmark evidence

Current result: **local-tool-pilot-002, 6/6 passed**. Read COMPLETED-LOCAL-BENCHMARK.md.

The original six-case run is preserved as measurement-invalid; the one-case recovery diagnostic is separate. Neither is pooled with the current score. LOCAL-MODEL-RESULTS.md is a historical partial report, not current status.

Run `python3 -P verify_bundle.py` from this directory for offline hash checks and separate frozen-grader replay of all three recorded attempts. It makes no model calls. Session databases, credentials and private reasoning are excluded; any filtered JSON has explicit original/projection digest lineage.

This is not an official DeepRSI score or a completed broad capability programme.
