import unittest

class ParentCases(unittest.TestCase):
    def test_three_subtests(self):
        for value in range(3):
            with self.subTest(value=value):
                self.assertGreaterEqual(value, 0)

    def test_plain_parent(self):
        self.assertTrue(True)
