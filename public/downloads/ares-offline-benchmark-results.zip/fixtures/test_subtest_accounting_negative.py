import unittest

class ParentCases(unittest.TestCase):
    def test_one_bad_subtest(self):
        for value in range(3):
            with self.subTest(value=value):
                self.assertNotEqual(value, 1)

    def test_plain_parent(self):
        self.assertTrue(True)
