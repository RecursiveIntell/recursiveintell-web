"""Separate readback verifier for offline benchmark receipts.

Recomputes hashes and counts from raw files; does not import the benchmark controller.
Verification of a valid failed receipt is not promotion to benchmark success.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import xml.etree.ElementTree as ET


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def verify_manifest(root: Path, records: list[dict]) -> list[str]:
    errors = []
    for record in records:
        relative = Path(record['path'])
        if relative.is_absolute() or '..' in relative.parts:
            errors.append('manifest_path_escape')
            continue
        path = root / relative
        try:
            if not path.parent.resolve().is_relative_to(root.resolve()):
                raise ValueError('parent symlink escape')
            info = path.lstat()
            if stat.S_IMODE(info.st_mode) != record['mode']:
                errors.append('mode_changed:' + record['path'])
            if record['kind'] == 'symlink':
                raw = os.fsencode(os.readlink(path))
            else:
                raw = path.read_bytes()
            if sha(raw) != record['sha256']:
                errors.append('bytes_changed:' + record['path'])
        except (OSError, ValueError):
            errors.append('manifest_unreadable:' + record['path'])
    return errors


def count_cases(path: Path) -> tuple[dict, list[str]]:
    raw = path.read_bytes()
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
        raise ValueError('forbidden_xml_declaration')
    root = ET.fromstring(raw)
    cases = list(root.iter('testcase'))
    if not cases or root.tag not in ('testsuite', 'testsuites'):
        raise ValueError('empty_or_invalid_junit')
    ids = [(case.get('classname'), case.get('name')) for case in cases]
    if len(set(ids)) != len(ids):
        raise ValueError('duplicate_case')
    totals = {'total': len(cases), 'passed': 0, 'failed': 0, 'errors': 0, 'skipped': 0}
    for case in cases:
        fields = [key for tag, key in (('failure', 'failed'), ('error', 'errors'), ('skipped', 'skipped'))
                  if case.find(tag) is not None]
        if len(fields) > 1:
            raise ValueError('ambiguous_case')
        totals[fields[0] if fields else 'passed'] += 1
    return totals, [case.get('name') for case in cases]


def main(run: Path) -> dict:
    run = run.resolve()
    summary = json.loads((run / 'summary.json').read_text())
    protocol = json.loads((run / 'protocol.json').read_text())
    before = json.loads((run / 'source-before.json').read_text())
    after = json.loads((run / 'source-after.json').read_text())
    errors = []
    runtime = Path(summary['runtime']).resolve()
    if before['revision'] != protocol['expected_revision'] or after['revision'] != before['revision']:
        errors.append('revision_binding_mismatch')
    for stage, data in (('before', before), ('after', after)):
        raw = json.dumps(data['tracked_manifest'], sort_keys=True, separators=(',', ':')).encode()
        if sha(raw) != data['tracked_manifest_sha256']:
            errors.append(stage + '_manifest_digest_invalid')
    if before['tracked_manifest'] != after['tracked_manifest']:
        errors.append('source_changed_during_execution')
    if before['production_timing_cache_sha256'] != after['production_timing_cache_sha256']:
        errors.append('production_timing_cache_changed')
    errors.extend(verify_manifest(runtime, after['tracked_manifest']))
    if sha((runtime / 'test_durations.json').read_bytes()) != after['production_timing_cache_sha256']:
        errors.append('production_timing_cache_changed_after_execution')
    harness_before = json.loads((run / 'harness-before.json').read_text())
    harness_after = json.loads((run / 'harness-after.json').read_text())
    if harness_before != harness_after:
        errors.append('harness_changed_during_execution')
    frozen_harness = run / 'frozen-harness'
    harness_root = frozen_harness if frozen_harness.is_dir() else run.parent.parent
    errors.extend(verify_manifest(harness_root, harness_after))
    if [record['file'] for record in summary['files']] != protocol['test_files']:
        errors.append('declared_file_denominator_mismatch')
    totals = {'total': 0, 'passed': 0, 'failed': 0, 'errors': 0, 'skipped': 0}
    outcomes = []
    for index, record in enumerate(summary['files']):
        for stage in ('collection', 'execution'):
            receipt = record.get(stage)
            if receipt is None:
                continue
            for stream in ('stdout', 'stderr'):
                path = Path(receipt[stream + '_path']).resolve()
                if not path.is_relative_to(run):
                    errors.append('log_path_escape')
                elif sha(path.read_bytes()) != receipt[stream + '_sha256']:
                    errors.append(f'{stage}_{stream}_hash_mismatch:{index}')
        if 'cases' in record:
            junit = run / f'cases-{index:02}.xml'
            counts, names = count_cases(junit)
            if counts != record['cases'] or sha(junit.read_bytes()) != record['junit_sha256']:
                errors.append('junit_readback_mismatch:' + str(index))
            collection = record['collection']
            nodeids = collection.get('collected_nodeids', [])
            expected_names = [nodeid.rsplit('::', 1)[-1] for nodeid in nodeids]
            if sorted(names) != sorted(expected_names):
                errors.append('collected_vs_executed_case_names_mismatch:' + str(index))
            if 'pytest_event_scope' in record:
                ledger = run / f'events-{index:02}.jsonl'
                events = [json.loads(line) for line in ledger.read_text().splitlines() if line]
                scope = record['pytest_event_scope']
                if sha(ledger.read_bytes()) != scope['event_ledger_sha256']:
                    errors.append('event_ledger_hash_mismatch:' + str(index))
                header = events[0]
                package = run.parent.parent / '.test-env/lib/python3.14/site-packages/_pytest'
                if (header.get('pytest_version') != '9.1.1'
                        or header.get('junitxml_source_sha256') != sha((package / 'junitxml.py').read_bytes())
                        or header.get('subtests_source_sha256') != sha((package / 'subtests.py').read_bytes())):
                    errors.append('event_producer_identity_mismatch:' + str(index))
                collected_events = [event for event in events if event['kind'] == 'collection']
                reports = [event for event in events if event['kind'] == 'report']
                parents = [event for event in reports if event['when'] == 'call' and not event['is_subtest']]
                subreports = [event for event in reports if event['is_subtest']]
                if (len(collected_events) != 1 or sorted(collected_events[0]['nodeids']) != sorted(nodeids)
                        or sorted(event['nodeid'] for event in parents) != sorted(nodeids)
                        or events[-1] != {'kind': 'finish', 'exit_code': 0}
                        or any(event['outcome'] != 'passed' or event['nodeid'] not in nodeids for event in reports)
                        or any(event['when'] != 'call' or event['report_type'] != '_pytest.subtests.SubtestReport' for event in subreports)):
                    errors.append('event_parent_or_subreport_mismatch:' + str(index))
                suites = list(ET.parse(junit).iter('testsuite'))
                if len(suites) != 1 or int(suites[0].get('tests', -1)) != len(parents) + len(subreports):
                    errors.append('native_junit_declared_total_unreconciled:' + str(index))
                if scope['parent_cases'] != len(parents) or scope['subtest_calls'] != len(subreports):
                    errors.append('event_scope_totals_mismatch:' + str(index))
            for key in totals:
                totals[key] += counts[key]
        outcomes.append({'file': record['file'], 'outcome': record['outcome'], 'cases': record.get('cases')})
    if totals != summary['conformance_cases']:
        errors.append('aggregate_denominator_mismatch')
    separate_subreports = sum(record.get('pytest_event_scope', {}).get('subtest_calls', 0) for record in summary['files'])
    if 'passed_subtest_reports_separate_not_independent_cases' in summary and separate_subreports != summary['passed_subtest_reports_separate_not_independent_cases']:
        errors.append('subreport_denominator_mismatch')
    micro = json.loads((run / 'microperformance.json').read_text()) if (run / 'microperformance.json').exists() else None
    if micro is not None:
        for case in micro['cases']:
            rows = [row for row in micro['raw_blocks'] if row['case'] == case['case']]
            if len(rows) != protocol['microperformance']['blocks']:
                errors.append('micro_block_count_mismatch:' + case['case'])
            if sum(row['operations'] for row in rows) != case['measured_operations']:
                errors.append('micro_operation_count_mismatch:' + case['case'])
            if any(row['elapsed_ns'] <= 0 or row['mean_ns_per_operation'] != row['elapsed_ns'] / row['operations'] for row in rows):
                errors.append('micro_raw_timing_invalid:' + case['case'])
    else:
        errors.append('micro_result_absent')
    passed = bool(summary['registered_track_complete']) and not errors
    return {
        'schema': 'AresOfflineBenchmarkReadbackVerificationV1', 'run': str(run),
        'mechanical_evidence_valid': not errors, 'offline_track_passed': passed,
        'full_evaluation_programme_complete': False, 'errors': errors,
        'recomputed_conformance_cases': totals, 'separate_subtest_reports': separate_subreports,
        'file_outcomes': outcomes,
        'micro_case_count': len(micro['cases']) if micro else 0,
        'micro_measured_operations': sum(c['measured_operations'] for c in micro['cases']) if micro else 0,
        'limitations': ['Same-controller second-method verification, not independent external scientific reproduction.',
                       'Does not establish official DeepRSI, agent/model performance, live owner activation or superiority.'],
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    result = main(args.run)
    if args.out:
        if args.out.exists():
            raise FileExistsError(args.out)
        args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['mechanical_evidence_valid'] and result['offline_track_passed'] else 1)
