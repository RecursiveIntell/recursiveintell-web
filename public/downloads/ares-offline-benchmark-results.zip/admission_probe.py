"""Real namespace admission probes, not an agent benchmark."""
import json
import os
from pathlib import Path
import socket
import sys

import ares_runtime
import pytest

protocol = json.loads(Path(sys.argv[1]).read_text())
runtime = Path(protocol['runtime']).resolve()
checks = {
    'runtime_import_exact': Path(ares_runtime.__file__).resolve().is_relative_to(runtime),
    'pytest_exact_version': pytest.__version__ == '9.1.1',
    'operator_auth_hidden': not Path('/home/sikmindz/.ares/auth.json').exists(),
    'operator_project_hidden': not Path('/home/sikmindz/Coding').exists(),
    'private_home': Path.home() != Path('/home/sikmindz'),
    'no_credential_environment': not any(k.endswith(('_API_KEY', '_TOKEN', '_SECRET', '_PASSWORD')) for k in os.environ),
}
probe = runtime / '.ares-benchmark-forbidden-write'
assert not probe.exists()
try:
    probe.write_text('must not be written')
except OSError as error:
    checks['source_write_denied'] = error.errno in (13, 30)
else:
    checks['source_write_denied'] = False
try:
    connection = socket.create_connection(('1.1.1.1', 443), timeout=0.3)
except OSError:
    checks['external_network_denied'] = True
else:
    connection.close()
    checks['external_network_denied'] = False
print(json.dumps({'checks': checks, 'all_passed': all(checks.values()),
                  'runtime_import': str(Path(ares_runtime.__file__).resolve()),
                  'python': sys.version, 'cpu_affinity': sorted(os.sched_getaffinity(0)),
                  'network_namespace': os.readlink('/proc/self/ns/net')}, indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
