# Ares offline runtime benchmark — recorded results

## Verdict and scope

**The registered CPU-only source-conformance and microperformance track completed. The full Ares evaluation programme and official DeepRSI benchmark did not.**

- **301 of 301 collected test cases passed** across 10 selected files; 0 failures, 0 errors, 0 skips.
- 33 successful native Pytest subtest call reports are recorded separately. They are not extra independent tests or tasks.
- 6 descriptive timing cases completed, with 20,100 measured operations plus declared warmups; every timed-operation oracle passed.
- Selected source and controller inputs remained unchanged during execution. A separate raw-artifact verifier recomputed hashes, case identities, event counters and totals without errors.
- No benchmark provider/model calls or paid inference occurred. This does not describe the cost of the surrounding chat or support reviews.

This is source-level engineering evidence, **not** an agent-performance, long-horizon, model-quality, authenticated live-owner, reliability-rate, superiority or RSI result. The active chat metadata is gpt-6.1-sol via openai-codex, but that model was not evaluated in this offline track.

## Exact target

- Release: `c52d38934e06184e335e699d12796769777ee0ff`.
- Source: `/home/sikmindz/.ares/runtime/releases/c52d38934e06184e335e699d12796769777ee0ff/source`.
- Tracked-source manifest SHA-256: `a2452d4e36a57a4709e22915e97be2ef3704f7a75c0d73eda3f3dafa0c6256f0`.
- Registered protocol and complete logs: `runs/cpu-runtime-002/`.
- Completed-at timestamp: `2026-10-13T07:05:11.593392+00:00`.
- Recorded run wall time: 242.29 seconds. It excludes pre-run environment setup and initial source hashing; it is not an end-user task-performance metric.

The target is the pinned selected-release source, not the operator's dirty development checkout and not a proof that every currently running Desktop/gateway process has adopted it.

## Conformance results

| Selected source test file | Passed collected cases | Outcome |
|---|---:|---|
| `tests/ares_runtime/test_contracts.py` | 6 | passed |
| `tests/ares_runtime/test_runtime_audit.py` | 9 | passed |
| `tests/ares_runtime/test_authority.py` | 15 | passed |
| `tests/ares_runtime/test_authority_failure_atomicity.py` | 11 | passed |
| `tests/ares_runtime/test_authority_fractional_time.py` | 16 | passed |
| `tests/ares_runtime/test_continuity_budget.py` | 40 | passed |
| `tests/ares_runtime/test_closure_projection_rebuild.py` | 12 | passed |
| `tests/ares_runtime/test_policy_basis_v2.py` | 126 | passed |
| `tests/ares_runtime/test_governed_context_materialization.py` | 54 | passed |
| `tests/ares_runtime/test_permit_readback.py` | 12 | passed |

These cases exercise declared runtime contracts, authority boundaries/failure atomicity/time semantics, context-budget decisions, closure projections, policy-basis/materialization and permit readback. Where fixtures provide owner callbacks or captured owner output, passing demonstrates consumer/fixture conformance—not authentication, production bootstrap or live owner activation. This is a targeted selection, not the whole product test suite or platform matrix.

## Local descriptive microperformance

Values below are **microseconds per operation**. Timings include Python fixture construction and correctness-oracle overhead. Each case has 20 blocks. P95 is the nearest-rank quantile of **block-average latency**, not individual-call tail latency.

| Timed operation | Measured operations | Median µs/op | P95 block-mean µs/op |
|---|---:|---:|---:|
| `closure_projection_create_with_oracle` | 4000 | 567.84 | 580.03 |
| `closure_projection_rebuild_with_oracle` | 4000 | 590.68 | 602.76 |
| `authority_reserve_commit_fixture_cycle` | 4000 | 123.28 | 126.43 |
| `context_pressure_decision_with_oracle` | 4000 | 4.99 | 5.13 |
| `runtime_snapshot_audit_with_oracle` | 4000 | 188.06 | 195.16 |
| `atomic_pointer_republication_and_readback` | 100 | 4307.82 | 4570.87 |

Five CPU cases run 200 operations per block; the filesystem case runs five. Each case has 20 warmup operations. Block order is randomized with seed 3112; workers are restricted to one CPU affinity core. The host was not a controlled, idle benchmark machine. These numbers are not portable performance guarantees and there is no competitor/baseline performance claim.

The pointer case republishes and reads back the same disposable pointer; it does not time full runtime activation/update/rollback. The runtime-audit inputs are declared process snapshots, not observations of all live services. The context-pressure decision case does not measure actual Context Governor compaction or long-context model quality.

## Repeat-run variation, retained rather than selected away

The first run's overall track was incomplete because of the JUnit accounting refusal, but its six microperformance cases and operation oracles did complete. Both timing sets are retained. Their Ares source manifest, micro-worker bytes, and timing protocol match exactly; only the conformance observer/accounting was amended before the second run.

| Operation | Attempt 001 median µs/op | Attempt 002 median µs/op |
|---|---:|---:|
| `closure_projection_create_with_oracle` | 1029.17 | 567.84 |
| `closure_projection_rebuild_with_oracle` | 1129.96 | 590.68 |
| `authority_reserve_commit_fixture_cycle` | 238.31 | 123.28 |
| `context_pressure_decision_with_oracle` | 9.18 | 4.99 |
| `runtime_snapshot_audit_with_oracle` | 325.74 | 188.06 |
| `atomic_pointer_republication_and_readback` | 13362.40 | 4307.82 |

The differences demonstrate why these are host- and run-specific observations. They are not evidence that the accounting amendment improved Ares performance, and neither run is discarded to present only favorable timing. Raw blocks for both attempts are included.

## Measurement integrity and retained failure

The controller first rejected the authority-failure-atomicity JUnit output: Pytest 9.1.1 declared 44 report units while emitting 11 parent testcase elements. The initial attempt remains preserved as incomplete in `runs/cpu-runtime-001/`; its receipt was not rewritten into success.

The corrected protocol uses a source-pinned, observational event ledger. It reconciles 11 parent cases plus 33 successful subtest call reports without inflating the independent-case denominator. Default count mismatches still fail without this corroborating ledger. Validation includes a real failed-subtest fixture that the scorer rejects. No Ares production assertion was relaxed or changed.

- Controller validity tests: 14 passed after the amendment, including failed/foreign subreport rejection, false-success accounting, timeout and live-descendant cleanup.
- Namespace admission: exact source imports, private HOME, operator auth/project masking, no credential environment, denied source writes and denied external network access all passed.
- Test execution: unmodified canonical per-file runner, one worker, zero file retries, pinned source-required pytest/pytest-asyncio overlay. This diagnostic overlay uses production dependency sites; it is not a full exact-lock CI environment or hosted Python/platform-matrix certificate.
- Source, tests and original installed duration cache are protected. Only a run-owned projection of the canonical timing cache is writable.
- Raw JUnit, event ledgers, collection node IDs, stdout/stderr, source/harness manifests and same-controller second-method verification are retained. Hashes establish byte identity, not independent scientific truth or tamper-proof custody.

## Unfinished programme lanes

The full requested programme remains incomplete. It is not legitimate to treat this offline track as its replacement.

1. Official DeepRSI executable task packs/private grading and third-party harness admission have not been established. Current public-source searches located descriptions/results, not an admitted executable package.
2. Local PCI inventory shows an AMD/ATI Barcelo display controller, not the published NVIDIA H200/B200/RTX PRO 6000 task environments. GPU compatibility remains a gate; no paid remote GPU was provisioned.
3. Model-backed task comparisons need an explicit finite budget, exact provider/model settings, credential-separated inference and whole-task isolation. No such agent trial was run.
4. Representative hidden tasks, same-model harness ablations, power/sample-size registration, all-worker cost accounting, transfer/learning, real long-horizon failure recovery and external reproduction remain unexecuted.
5. No public leaderboard submission, publication, deployment, commit, push or production configuration/credential edit occurred.

## Files, rollback and auditor commands

Benchmark implementation and records are under `/home/sikmindz/work/ares-benchmark-program`. The isolated test overlay is `.test-env/`; the production venv was not modified. No data migration occurred. Retain both attempts and admission/negative-witness receipts. Rollback is archival/removal of this run-owned workspace only after evidence retention; there is no production runtime rollback to perform.

Read back the recorded result (choose a new output filename because verification receipts are append-only):

```bash
/home/sikmindz/work/ares-benchmark-program/.test-env/bin/python /home/sikmindz/work/ares-benchmark-program/verify_results.py \
  /home/sikmindz/work/ares-benchmark-program/runs/cpu-runtime-002 \
  --out /home/sikmindz/work/ares-benchmark-program/runs/cpu-runtime-002/verification-auditor-new.json
```

Re-execute the exact registered offline track into a fresh run directory:

```bash
/home/sikmindz/work/ares-benchmark-program/.test-env/bin/python /home/sikmindz/work/ares-benchmark-program/benchmark.py \
  --run-name cpu-runtime-auditor-new
```

The local rerun depends on the exact pinned runtime and production dependency sites still being available. For another host, provision matching source/interpreter/dependencies and namespace tooling before changing paths; that independent reproduction has not been performed.

## Public claim boundary

Public review is recorded separately; this report does not authorize publication. The strongest current claim is: **the specified source-conformance checks passed on the pinned release, and the specified local microperformance observations were recorded.** No superiority, full-capability, live-stack, official DeepRSI or self-improvement claim follows.
