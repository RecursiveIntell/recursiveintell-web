"""Build a private, explicitly scoped result report from verified raw artifacts."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'runs/cpu-runtime-002'
summary = json.loads((RUN / 'summary.json').read_text())
verification = json.loads((RUN / 'verification.json').read_text())
micro = json.loads((RUN / 'microperformance.json').read_text())
assert verification['mechanical_evidence_valid'] and verification['offline_track_passed']
assert summary['registered_track_complete'] and not summary['full_evaluation_programme_complete']
report_path = ROOT / 'RESULTS.draft.md'
json_path = ROOT / 'results.json'
if report_path.exists() or json_path.exists():
    raise FileExistsError('result files are append-only; use a new version')
counts = verification['recomputed_conformance_cases']
case_rows = '\n'.join(f"| `{row['file']}` | {row['cases']['passed']} | {row['outcome']} |"
                       for row in verification['file_outcomes'])
timing_rows = '\n'.join(
    f"| `{case['case']}` | {case['measured_operations']} | {case['median_us_per_operation']:.2f} | {case['p95_block_mean_us_per_operation']:.2f} |"
    for case in micro['cases'])
data = {
    'schema': 'AresBenchmarkRecordedResultsV1',
    'scope': summary['scope'], 'offline_registered_track_complete': True,
    'full_ares_evaluation_programme_complete': False, 'official_deeprsi_completed': False,
    'model_or_agent_task_performance_evaluated': False,
    'selected_release_revision': summary['revision'], 'runtime': summary['runtime'],
    'source_manifest_sha256': summary['source_manifest_sha256'],
    'source_unchanged': summary['source_unchanged'], 'harness_unchanged': summary['harness_unchanged'],
    'case_counts': counts, 'separate_subtest_reports': verification['separate_subtest_reports'],
    'case_files': verification['file_outcomes'], 'microperformance': micro['cases'],
    'micro_measured_operations': verification['micro_measured_operations'],
    'benchmark_provider_calls': 0, 'benchmark_paid_inference_usd': 0,
    'benchmark_wall_seconds': summary['wall_seconds'],
    'chat_model_metadata': {'model': 'gpt-6.1-sol', 'provider': 'openai-codex', 'not_evaluated_by_this_track': True},
    'initial_attempt': {'path': str(ROOT / 'runs/cpu-runtime-001'),
                        'status': 'incomplete_due_to_junit_accounting_refusal', 'retained': True},
    'remaining_gates': summary['blocked_programme_lanes'],
    'public_wording_review': 'pending',
    'limitations': micro['limitations'] + verification['limitations'],
}
json_path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n', encoding='utf-8')
text = f'''# Ares offline runtime benchmark — recorded results

## Verdict and scope

**The registered CPU-only source-conformance and microperformance track completed. The full Ares evaluation programme and official DeepRSI benchmark did not.**

- **{counts['passed']} of {counts['total']} collected test cases passed** across {len(verification['file_outcomes'])} selected files; {counts['failed']} failures, {counts['errors']} errors, {counts['skipped']} skips.
- {verification['separate_subtest_reports']} successful native Pytest subtest call reports are recorded separately. They are not extra independent tests or tasks.
- {verification['micro_case_count']} descriptive timing cases completed, with {verification['micro_measured_operations']:,} measured operations plus declared warmups; every timed-operation oracle passed.
- Selected source and controller inputs remained unchanged during execution. A separate raw-artifact verifier recomputed hashes, case identities, event counters and totals without errors.
- No benchmark provider/model calls or paid inference occurred. This does not describe the cost of the surrounding chat or support reviews.

This is source-level engineering evidence, **not** an agent-performance, long-horizon, model-quality, authenticated live-owner, reliability-rate, superiority or RSI result. The active chat metadata is gpt-6.1-sol via openai-codex, but that model was not evaluated in this offline track.

## Exact target

- Release: `{summary['revision']}`.
- Source: `{summary['runtime']}`.
- Tracked-source manifest SHA-256: `{summary['source_manifest_sha256']}`.
- Registered protocol and complete logs: `runs/cpu-runtime-002/`.
- Completed-at timestamp: `{summary['completed_at_utc']}`.
- Recorded run wall time: {summary['wall_seconds']:.2f} seconds. It excludes pre-run environment setup and initial source hashing; it is not an end-user task-performance metric.

The target is the pinned selected-release source, not the operator's dirty development checkout and not a proof that every currently running Desktop/gateway process has adopted it.

## Conformance results

| Selected source test file | Passed collected cases | Outcome |
|---|---:|---|
{case_rows}

These cases exercise declared runtime contracts, authority boundaries/failure atomicity/time semantics, context-budget decisions, closure projections, policy-basis/materialization and permit readback. Where fixtures provide owner callbacks or captured owner output, passing demonstrates consumer/fixture conformance—not authentication, production bootstrap or live owner activation. This is a targeted selection, not the whole product test suite or platform matrix.

## Local descriptive microperformance

Values below are **microseconds per operation**. Timings include Python fixture construction and correctness-oracle overhead. Each case has 20 blocks. P95 is the nearest-rank quantile of **block-average latency**, not individual-call tail latency.

| Timed operation | Measured operations | Median µs/op | P95 block-mean µs/op |
|---|---:|---:|---:|
{timing_rows}

Five CPU cases run 200 operations per block; the filesystem case runs five. Each case has 20 warmup operations. Block order is randomized with seed 3112; workers are restricted to one CPU affinity core. The host was not a controlled, idle benchmark machine. These numbers are not portable performance guarantees and there is no competitor/baseline performance claim.

The pointer case republishes and reads back the same disposable pointer; it does not time full runtime activation/update/rollback. The runtime-audit inputs are declared process snapshots, not observations of all live services. The context-pressure decision case does not measure actual Context Governor compaction or long-context model quality.

## Measurement integrity and retained failure

The controller first rejected the authority-failure-atomicity JUnit output: Pytest 9.1.1 declared 44 report units while emitting 11 parent testcase elements. The initial attempt remains preserved as incomplete in `runs/cpu-runtime-001/`; its receipt was not rewritten into success.

The corrected protocol uses a source-pinned, observational event ledger. It reconciles 11 parent cases plus 33 successful subtest call reports without inflating the independent-case denominator. Default count mismatches still fail without this corroborating ledger. Validation includes a real failed-subtest fixture that the scorer rejects. No Ares production assertion was relaxed or changed.

- Controller validity tests: 14 passed after the amendment, including failed/foreign subreport rejection, false-success accounting, timeout and live-descendant cleanup.
- Namespace admission: exact source imports, private HOME, operator auth/project masking, no credential environment, denied source writes and denied external network access all passed.
- Test execution: unmodified canonical per-file runner, one worker, zero file retries, pinned source-required pytest/pytest-asyncio overlay. This diagnostic overlay uses production dependency sites; it is not a full exact-lock CI environment or hosted Python/platform-matrix certificate.
- Source, tests and original installed duration cache are protected. Only a run-owned projection of the canonical timing cache is writable.
- Raw JUnit, event ledgers, collection node IDs, stdout/stderr, source/harness manifests and same-controller second-method verification are retained. Hashes establish byte identity, not independent scientific truth or tamper-proof custody.

## Unfinished programme lanes

The full requested programme remains incomplete. It is not legitimate to treat this offline track as its replacement.

1. Official DeepRSI executable task packs/private grading and third-party harness admission have not been established. Current public-source searches located descriptions/results, not an admitted executable package.
2. Local PCI inventory shows an AMD/ATI Barcelo display controller, not the published NVIDIA H200/B200/RTX PRO 6000 task environments. GPU compatibility remains a gate; no paid remote GPU was provisioned.
3. Model-backed task comparisons need an explicit finite budget, exact provider/model settings, credential-separated inference and whole-task isolation. No such agent trial was run.
4. Representative hidden tasks, same-model harness ablations, power/sample-size registration, all-worker cost accounting, transfer/learning, real long-horizon failure recovery and external reproduction remain unexecuted.
5. No public leaderboard submission, publication, deployment, commit, push or production configuration/credential edit occurred.

## Files, rollback and auditor commands

Benchmark implementation and records are under `{ROOT}`. The isolated test overlay is `.test-env/`; the production venv was not modified. No data migration occurred. Retain both attempts and admission/negative-witness receipts. Rollback is archival/removal of this run-owned workspace only after evidence retention; there is no production runtime rollback to perform.

Read back the recorded result (choose a new output filename because verification receipts are append-only):

```bash
{ROOT}/.test-env/bin/python {ROOT}/verify_results.py \\
  {RUN} \\
  --out {RUN}/verification-auditor-new.json
```

Re-execute the exact registered offline track into a fresh run directory:

```bash
{ROOT}/.test-env/bin/python {ROOT}/benchmark.py \\
  --run-name cpu-runtime-auditor-new
```

The local rerun depends on the exact pinned runtime and production dependency sites still being available. For another host, provision matching source/interpreter/dependencies and namespace tooling before changing paths; that independent reproduction has not been performed.

## Public claim boundary

Wording review is pending. The strongest current claim is: **the specified source-conformance checks passed on the pinned release, and the specified local microperformance observations were recorded.** No superiority, full-capability, live-stack, official DeepRSI or self-improvement claim follows.
'''
report_path.write_text(text, encoding='utf-8')
print(json.dumps({'report': str(report_path), 'results_json': str(json_path),
                  'report_sha256': hashlib.sha256(report_path.read_bytes()).hexdigest(),
                  'cases': counts, 'offline_track_complete': True,
                  'full_programme_complete': False}, indent=2))
