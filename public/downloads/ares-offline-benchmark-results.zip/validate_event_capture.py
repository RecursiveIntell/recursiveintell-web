"""Real positive/negative witness for the exact native Pytest event producer."""
import json
import os
from pathlib import Path
from benchmark import WORKSPACE, namespace_command, run_owned, parse_junit, read_event_ledger, write_json

run = WORKSPACE / 'admissions' / 'event-capture-001'
run.mkdir(parents=True, exist_ok=False)
protocol = json.loads((WORKSPACE / 'protocol.json').read_text())
runtime = Path(protocol['runtime'])
python = WORKSPACE / '.test-env/bin/python'
records = []
for variant in ('positive', 'negative'):
    junit = run / f'{variant}.xml'
    events = run / f'{variant}.jsonl'
    fixture = WORKSPACE / 'fixtures' / f'test_subtest_accounting_{variant}.py'
    command = namespace_command(runtime, run, [str(python), '-P', '-m', 'pytest', str(fixture),
                    '-q', '-p', 'no:cacheprovider', '-p', 'ares_report_capture',
                    f'--junitxml={junit}', f'--ares-event-ledger={events}'], min(os.sched_getaffinity(0)))
    receipt = run_owned(command, runtime, {'PATH': '/usr/bin:/bin'}, run / variant, 30)
    if variant == 'positive':
        assert receipt['exit_code'] == 0 and receipt['process_group_clean']
        counts = parse_junit(junit, event_ledger=events)
        scope = read_event_ledger(events)
        assert counts == {'total': 2, 'passed': 2, 'failed': 0, 'errors': 0, 'skipped': 0}
        assert scope['parent_cases'] == 2 and scope['subtest_calls'] == 3
        records.append({'variant': variant, 'counts': counts, 'event_scope': scope,
                        'receipt': receipt, 'witness_passed': True})
    else:
        assert receipt['exit_code'] == 1 and receipt['process_group_clean']
        try:
            parse_junit(junit, event_ledger=events)
        except ValueError as error:
            records.append({'variant': variant, 'receipt': receipt,
                            'scorer_rejected': str(error), 'witness_passed': True})
        else:
            raise AssertionError('FAILED_SUBTEST_PROMOTED')
write_json(run / 'summary.json', {'schema': 'PytestEventCaptureQualificationV1',
                                 'all_witnesses_passed': True, 'variants': records})
print(json.dumps({'positive_parent_cases': 2, 'positive_subtest_reports': 3,
                  'failed_subtest_rejected': True, 'all_witnesses_passed': True}, indent=2))
