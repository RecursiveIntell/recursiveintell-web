"""Run exact namespace admission and retain its logs before conformance."""
import argparse
import json
import os
from pathlib import Path

from benchmark import WORKSPACE, namespace_command, run_owned, write_json, digest_bytes

parser = argparse.ArgumentParser()
parser.add_argument('--name', required=True)
args = parser.parse_args()
if '/' in args.name or args.name in ('', '.', '..'):
    raise SystemExit('invalid admission name')
run = WORKSPACE / 'admissions' / args.name
run.mkdir(parents=True, exist_ok=False)
protocol = WORKSPACE / 'protocol.json'
runtime = Path(json.loads(protocol.read_text())['runtime'])
python = WORKSPACE / '.test-env/bin/python'
command = namespace_command(runtime, run, [str(python), '-P', str(WORKSPACE / 'admission_probe.py'), str(protocol)], min(os.sched_getaffinity(0)))
protocol_before = digest_bytes(protocol.read_bytes())
result = run_owned(command, runtime, {'PATH': '/usr/bin:/bin', 'HOME': str(run / 'home')}, run / 'probe', 30)
result['protocol_sha256_before'] = protocol_before
result['protocol_sha256_after'] = digest_bytes(protocol.read_bytes())
result['protocol_unchanged'] = result['protocol_sha256_before'] == result['protocol_sha256_after']
write_json(run / 'receipt.json', result)
print(Path(result['stdout_path']).read_text())
print(Path(result['stderr_path']).read_text())
raise SystemExit(0 if result['exit_code'] == 0 and not result['timed_out'] and result['process_group_clean'] and result['protocol_unchanged'] else 1)
