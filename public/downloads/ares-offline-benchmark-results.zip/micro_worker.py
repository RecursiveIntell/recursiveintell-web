"""Measured offline operations on the exact selected Ares source.

Every timed operation checks its outcome. Timings include fixture/oracle overhead.
No inference, production store, daemon, permission grant or external effect occurs.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
import random
import resource
import statistics
import sys
import tempfile
import time

import ares_runtime
from ares_runtime import AresRuntimeLayout, InstalledRuntimePointer, ReleaseReference
from ares_runtime import authority
from ares_runtime.collaboration import ClosureProjector
from ares_runtime.continuity.budget import (
    CountMethod, Disposition, InputCount, PressurePolicy, RouteBudget, decide_pressure,
)
from ares_runtime.runtime_audit import ManagedRuntimeProcess, audit_process_snapshots


def main(protocol_path: Path, output: Path) -> None:
    protocol = json.loads(protocol_path.read_text())
    runtime = Path(protocol['runtime']).resolve()
    imported = Path(ares_runtime.__file__).resolve()
    if not imported.is_relative_to(runtime):
        raise RuntimeError('RUNTIME_IMPORT_IDENTITY_MISMATCH')
    if output.exists():
        raise FileExistsError(output)
    config = protocol['microperformance']
    projector = ClosureProjector()

    def project(prior=None):
        return projector.project('mission:benchmark', 'engineering', {'test': True},
                                 source_event_refs=('event:fixture',),
                                 source_event_exists=lambda reference: reference == 'event:fixture',
                                 previous_projection=prior)

    closed = project()
    expected_bytes = closed.canonical_bytes()

    def closure_create():
        value = project()
        assert value.canonical_bytes() == expected_bytes
        assert value.to_dict()['state'] == 'closed'

    def closure_rebuild():
        value = project(closed)
        assert value.canonical_bytes() == expected_bytes
        assert value.artifact_digest == closed.artifact_digest

    def reserve_commit():
        scope = authority.AuthorityScopeV1(
            scope={'tool': 'write_file', 'target': 'path:/fixture', 'use_count': 1},
            generation=1, holder='holder:benchmark')
        scope.reserve(consumption_ref='consume:fixture', args_digest='sha256:' + 'b' * 64,
                      target_ref='path:/fixture')
        result = scope.commit('consume:fixture', effect_receipt_digest='sha256:' + 'c' * 64)
        assert result['record']['state'] == 'committed'
        assert result['open_reservations'] == 0 and result['charged_total'] == 1

    route = 'route:benchmark'
    budget = RouteBudget(route, 1000, 1400, 200, 0)
    current = InputCount(route, 'sha256:' + 'a' * 64, 600, CountMethod.QUALIFIED_UPPER_BOUND)
    candidate = InputCount(route, 'sha256:' + 'b' * 64, 150, CountMethod.QUALIFIED_UPPER_BOUND)
    policy = PressurePolicy()

    def pressure_decision():
        value = decide_pressure(budget, current, policy=policy, next_segment_growth=100,
                                compaction_exhausted=True, no_progress_rebases=0, candidate=candidate)
        assert value.disposition is Disposition.REBASE_CANDIDATE
        assert value.execution_authorized is False
        assert value.current_runway == 400 and value.candidate_runway == 850

    python = Path(sys.executable).resolve()
    process = ManagedRuntimeProcess(
        pid=100, ppid=1, role='gateway', revision=protocol['expected_revision'],
        executable=python, cwd=runtime,
        argv=(str(sys.executable), '-m', 'hermes_cli.main', 'gateway'),
        deleted_runtime_mappings=())

    def runtime_audit():
        value = audit_process_snapshots([process], active_revision=protocol['expected_revision'],
                                       active_source=runtime, expected_python=python)
        assert value.ok is True and value.managed_count == 1 and not value.stale

    with tempfile.TemporaryDirectory(prefix='pointer-fixture-', dir=output.parent) as directory:
        layout = AresRuntimeLayout(Path(directory) / 'layout')
        reference = ReleaseReference('sealed_candidate', 'a' * 64, 'b' * 64, 'c' * 64)
        pointer = InstalledRuntimePointer(generation=1, current=reference, previous=None,
                                         committed_transaction_id='d' * 64,
                                         state_root=str(layout.root.parent))

        def pointer_cycle():
            layout.write_pointer_atomic(pointer)
            assert layout.read_pointer() == pointer
            assert layout.pointer_path.read_bytes() == pointer.canonical_bytes()
            assert not tuple(layout.root.glob('.release-state-*.tmp'))

        operations = {
            'closure_projection_create_with_oracle': (closure_create, False),
            'closure_projection_rebuild_with_oracle': (closure_rebuild, False),
            'authority_reserve_commit_fixture_cycle': (reserve_commit, False),
            'context_pressure_decision_with_oracle': (pressure_decision, False),
            'runtime_snapshot_audit_with_oracle': (runtime_audit, False),
            'atomic_pointer_republication_and_readback': (pointer_cycle, True),
        }
        for function, _ in operations.values():
            for _ in range(config['warmup_operations_per_case']):
                function()
        rng = random.Random(config['seed'])
        samples = []
        for block in range(config['blocks']):
            order = list(operations)
            rng.shuffle(order)
            for position, name in enumerate(order):
                function, filesystem = operations[name]
                repetitions = (config['operations_per_filesystem_block'] if filesystem
                               else config['operations_per_cpu_block'])
                start = time.perf_counter_ns()
                for _ in range(repetitions):
                    function()
                elapsed = time.perf_counter_ns() - start
                samples.append({'block': block, 'order': position, 'case': name,
                                'operations': repetitions, 'elapsed_ns': elapsed,
                                'mean_ns_per_operation': elapsed / repetitions})
    summaries = []
    for name in operations:
        rows = [r for r in samples if r['case'] == name]
        values = [r['mean_ns_per_operation'] for r in rows]
        ordered = sorted(values)
        summaries.append({
            'case': name, 'blocks': len(rows), 'measured_operations': sum(r['operations'] for r in rows),
            'mean_us_per_operation': statistics.mean(values) / 1000,
            'median_us_per_operation': statistics.median(values) / 1000,
            'p95_block_mean_us_per_operation': ordered[math.ceil(0.95 * len(ordered)) - 1] / 1000,
            'minimum_block_mean_us_per_operation': min(values) / 1000,
            'maximum_block_mean_us_per_operation': max(values) / 1000,
        })
    report = {
        'schema': 'AresOfflineRuntimeMicroperformanceV1', 'all_operation_oracles_passed': True,
        'runtime_import': str(imported), 'python': sys.version, 'python_executable': str(python),
        'cpu_affinity': sorted(__import__('os').sched_getaffinity(0)),
        'max_worker_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'microperformance_protocol': config, 'cases': summaries, 'raw_blocks': samples,
        'limitations': [
            'Descriptive microperformance only, on a contended host; no superiority comparison or generalization interval.',
            'Times include Python fixture construction and correctness-oracle overhead.',
            'Policy/event/process owner inputs are declared local fixtures, not authenticated live owner observations.',
            'Filesystem case repeats the same pointer; it is not full release activation/update/rollback timing.',
            'p95 is a quantile of block-average latencies, not per-call tail latency.',
        ],
    }
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'oracles_passed': True, 'cases': len(summaries),
                      'measured_operations': sum(r['measured_operations'] for r in summaries)}))


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('usage: micro_worker.py PROTOCOL_JSON OUTPUT_JSON')
    main(Path(sys.argv[1]), Path(sys.argv[2]))
