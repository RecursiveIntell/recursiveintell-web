"""Package only benchmark-owned reports/evidence; omit venv, homes and profile DBs."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
review = json.loads((ROOT / 'public-review.json').read_text())
report = ROOT / 'RESULTS.review.md'
report_hash = hashlib.sha256(report.read_bytes()).hexdigest()
if report_hash != review['report_sha256']:
    raise ValueError('REPORT_CHANGED_AFTER_REVIEW')
if review['status'] != 'scoped_wording_approved':
    raise ValueError('SCOPED_WORDING_REVIEW_NOT_APPROVED')
run = ROOT / 'runs/cpu-runtime-002'
verification = json.loads((run / 'verification.json').read_text())
if not verification['mechanical_evidence_valid'] or not verification['offline_track_passed']:
    raise ValueError('OFFLINE_RESULT_NOT_VERIFIED')
final = ROOT / 'RESULTS.md'
if final.exists():
    raise FileExistsError(final)
shutil.copy2(report, final)
# Preserve source blobs for the accepted attempt before any later maintenance.
harness = json.loads((run / 'harness-before.json').read_text())
frozen = run / 'frozen-harness'
if frozen.exists():
    raise FileExistsError(frozen)
for item in harness:
    source = ROOT / item['path']
    if hashlib.sha256(source.read_bytes()).hexdigest() != item['sha256']:
        raise ValueError('HARNESS_SOURCE_CHANGED')
    target = frozen / item['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
allowed = [
    'RESULTS.md', 'RESULTS.review.md', 'results.final.json', 'protocol.json',
    'environment.json', 'attempt-history.json', 'public-review.json',
    'benchmark.py', 'micro_worker.py', 'verify_results.py', 'test_benchmark.py',
    'admit.py', 'admission_probe.py', 'validate_event_capture.py', 'record_results.py',
    'package_results.py',
]
files = [(ROOT / name, name) for name in allowed]
for directory in ('runs', 'admissions', 'fixtures'):
    for path in sorted((ROOT / directory).rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(ROOT)
        if any(part in {'home', 'scratch', '__pycache__', '.cache', '.local'} for part in relative.parts):
            continue
        if path.suffix in {'.pyc', '.pyo'} or path.name == 'test_durations.json':
            continue
        files.append((path, relative.as_posix()))
for name in ('panel.json', 'verification.json', 'profiles/public.stdout.txt'):
    source = ROOT / 'reviews/public-run-001' / name
    if source.is_file():
        files.append((source, 'review/' + name))
manifest = {
    'schema': 'AresOfflineBenchmarkResultBundleV1',
    'scope': 'private offline source-conformance/microperformance packet; not official DeepRSI or a complete Ares programme',
    'publication_authorized': False,
    'files': [{'path': name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
               'bytes': path.stat().st_size} for path, name in files],
    'excluded': 'production credentials/stores, test environment packages, run-owned homes, reviewer session databases and private memory',
}
output = ROOT / 'ares-offline-benchmark-results.zip'
if output.exists():
    raise FileExistsError(output)
with zipfile.ZipFile(output, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path, name in files:
        archive.write(path, name)
    archive.writestr('MANIFEST.json', json.dumps(manifest, indent=2, sort_keys=True) + '\n')
with zipfile.ZipFile(output) as archive:
    if archive.testzip() is not None:
        raise ValueError('ARCHIVE_CRC_FAILURE')
    recorded = json.loads(archive.read('MANIFEST.json'))
    if set(archive.namelist()) != {'MANIFEST.json'} | {item['path'] for item in recorded['files']}:
        raise ValueError('ARCHIVE_FILESET_MISMATCH')
    for item in recorded['files']:
        data = archive.read(item['path'])
        if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise ValueError('ARCHIVE_DIGEST_MISMATCH')
receipt = {'schema': 'AresOfflineBenchmarkDeliveryV1', 'report': str(final),
           'report_sha256': report_hash, 'bundle': str(output),
           'bundle_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
           'bundle_entries': len(files) + 1, 'bundle_bytes': output.stat().st_size,
           'crc_and_manifest_verified': True, 'offline_track_complete': True,
           'full_evaluation_programme_complete': False, 'publication_authorized': False}
receipt_path = ROOT / 'delivery-receipt.json'
if receipt_path.exists():
    raise FileExistsError(receipt_path)
receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
