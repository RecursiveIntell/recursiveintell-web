"""Controller validity tests; these are not Ares product tests."""
import json
import hashlib
import os
from pathlib import Path
import sys
import tempfile
import unittest

from benchmark import hash_paths, parse_junit, run_owned


class ControllerTests(unittest.TestCase):
    def test_hashes_bind_content_and_mode(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'fixture.txt'
            path.write_text('first')
            first = hash_paths(root, ['fixture.txt'])
            path.write_text('second')
            second = hash_paths(root, ['fixture.txt'])
            self.assertNotEqual(first, second)
            path.chmod(0o600)
            third = hash_paths(root, ['fixture.txt'])
            self.assertEqual(second[0]['sha256'], third[0]['sha256'])
            self.assertNotEqual(second[0]['mode'], third[0]['mode'])

    def test_hashes_refuse_path_escape(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):
                hash_paths(Path(directory), ['../escape'])

    def test_hashes_refuse_parent_symlink_escape(self):
        with tempfile.TemporaryDirectory() as directory, tempfile.TemporaryDirectory() as outside:
            root = Path(directory)
            (Path(outside) / 'secret').write_text('not input')
            (root / 'outside').symlink_to(outside, target_is_directory=True)
            with self.assertRaises(ValueError):
                hash_paths(root, ['outside/secret'])

    def test_hashes_record_symlink_without_following(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'link').symlink_to('/does/not/exist')
            result = hash_paths(root, ['link'])
            self.assertEqual(result[0]['kind'], 'symlink')
            self.assertEqual(result[0]['target'], '/does/not/exist')

    def test_junit_counts_actual_outcomes(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'cases.xml'
            path.write_text('<testsuites><testsuite tests="4" failures="1" errors="1" skipped="1">'
                            '<testcase classname="suite" name="pass"/>'
                            '<testcase classname="suite" name="fail"><failure/></testcase>'
                            '<testcase classname="suite" name="error"><error/></testcase>'
                            '<testcase classname="suite" name="skip"><skipped/></testcase>'
                            '</testsuite></testsuites>')
            result = parse_junit(path)
            self.assertEqual(result, {'total': 4, 'passed': 1, 'failed': 1, 'errors': 1, 'skipped': 1})

    def _event_ledger(self, path, *, failed_subtest=False, foreign_subtest=False):
        from _pytest import junitxml, subtests
        header = {'kind': 'header', 'schema': 'PytestEventLedgerV1', 'pytest_version': '9.1.1',
                  'junitxml_source_sha256': hashlib.sha256(Path(junitxml.__file__).read_bytes()).hexdigest(),
                  'subtests_source_sha256': hashlib.sha256(Path(subtests.__file__).read_bytes()).hexdigest()}
        node = 'fixture.py::test_one'
        rows = [header, {'kind': 'collection', 'nodeids': [node]}]
        for when in ('setup', 'call', 'teardown'):
            if when == 'call':
                rows.append({'kind': 'report', 'nodeid': 'fixture.py::other' if foreign_subtest else node,
                             'when': 'call', 'outcome': 'failed' if failed_subtest else 'passed',
                             'is_subtest': True, 'report_type': '_pytest.subtests.SubtestReport'})
            rows.append({'kind': 'report', 'nodeid': node, 'when': when, 'outcome': 'passed',
                         'is_subtest': False, 'report_type': '_pytest.reports.TestReport'})
        rows.append({'kind': 'finish', 'exit_code': 1 if failed_subtest else 0})
        path.write_text('\n'.join(json.dumps(row) for row in rows) + '\n')

    def test_subtest_counter_requires_exact_event_ledger(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'subtests.xml'
            path.write_text('<testsuites><testsuite tests="2" failures="0" errors="0" skipped="0">'
                            '<testcase classname="fixture" name="test_one"/></testsuite></testsuites>')
            ledger = Path(directory) / 'events.jsonl'
            self._event_ledger(ledger)
            result = parse_junit(path, event_ledger=ledger)
            self.assertEqual(result['total'], 1)
            self.assertEqual(result['passed'], 1)
            with self.assertRaises(ValueError):
                parse_junit(path)

    def test_failed_subtest_cannot_be_promoted_by_parent_junit(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'subtests.xml'
            path.write_text('<testsuites><testsuite tests="2" failures="0" errors="0" skipped="0">'
                            '<testcase classname="fixture" name="test_one"/></testsuite></testsuites>')
            ledger = Path(directory) / 'events.jsonl'
            self._event_ledger(ledger, failed_subtest=True)
            with self.assertRaises(ValueError):
                parse_junit(path, event_ledger=ledger)

    def test_foreign_subtest_cannot_explain_a_counter_mismatch(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'subtests.xml'
            path.write_text('<testsuites><testsuite tests="2" failures="0" errors="0" skipped="0">'
                            '<testcase classname="fixture" name="test_one"/></testsuite></testsuites>')
            ledger = Path(directory) / 'events.jsonl'
            self._event_ledger(ledger, foreign_subtest=True)
            with self.assertRaises(ValueError):
                parse_junit(path, event_ledger=ledger)

    def test_empty_junit_is_not_completion(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'empty.xml'
            path.write_text('<testsuites/>')
            with self.assertRaises(ValueError):
                parse_junit(path)

    def test_declared_count_mismatch_is_not_success(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'mismatch.xml'
            path.write_text('<testsuites><testsuite tests="2" failures="0" errors="0" skipped="0">'
                            '<testcase classname="suite" name="only"/></testsuite></testsuites>')
            with self.assertRaises(ValueError):
                parse_junit(path)

    def test_duplicate_case_and_entity_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'invalid.xml'
            for text in (
                '<testsuites><testsuite><testcase classname="s" name="n"/>'
                '<testcase classname="s" name="n"/></testsuite></testsuites>',
                '<!DOCTYPE x [<!ENTITY e "bad">]><testsuites/>',
            ):
                path.write_text(text)
                with self.assertRaises(ValueError):
                    parse_junit(path)

    def test_real_exit_code_and_output_are_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            result = run_owned([sys.executable, '-c', 'print("witness"); raise SystemExit(7)'],
                               root, {'PATH': '/usr/bin:/bin'}, root / 'failed', 10)
            self.assertEqual(result['exit_code'], 7)
            self.assertFalse(result['timed_out'])
            self.assertTrue(result['process_group_clean'])
            self.assertIn('witness', Path(result['stdout_path']).read_text())

    def test_timeout_kills_owned_group(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            result = run_owned([sys.executable, '-c', 'import time; time.sleep(30)'],
                               root, {'PATH': '/usr/bin:/bin'}, root / 'timeout', 0.15)
            self.assertTrue(result['timed_out'])
            self.assertTrue(result['process_group_clean'])
            self.assertNotEqual(result['exit_code'], 0)

    def test_normal_parent_exit_does_not_leave_live_descendant(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            code = 'import subprocess,sys; subprocess.Popen([sys.executable,"-c","import time;time.sleep(30)"]); print("parent complete")'
            result = run_owned([sys.executable, '-c', code], root,
                               {'PATH': '/usr/bin:/bin'}, root / 'descendant', 10)
            self.assertEqual(result['exit_code'], 0)
            self.assertTrue(result['process_group_clean'])
            self.assertTrue(result['cleanup_signals'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
