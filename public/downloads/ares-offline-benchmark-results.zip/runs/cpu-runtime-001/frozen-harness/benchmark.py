"""Offline Ares source-conformance controller. No provider calls or production writes.

The runner owns evidence collection, not Ares authority or benchmark task truth.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

WORKSPACE = Path(__file__).resolve().parent


def digest_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def hash_paths(root: Path, paths: list[str]) -> list[dict]:
    result = []
    for name in sorted(set(paths)):
        relative = Path(name)
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('PATH_OUTSIDE_ROOT')
        path = root / relative
        if not path.parent.resolve().is_relative_to(root.resolve()):
            raise ValueError('PATH_OUTSIDE_ROOT')
        info = path.lstat()
        item = {'path': name, 'mode': stat.S_IMODE(info.st_mode)}
        if stat.S_ISLNK(info.st_mode):
            target = os.readlink(path)
            item.update(kind='symlink', target=target,
                        sha256=digest_bytes(os.fsencode(target)))
        elif stat.S_ISREG(info.st_mode):
            item.update(kind='file', sha256=digest_bytes(path.read_bytes()), bytes=info.st_size)
        else:
            raise ValueError('NONREGULAR_SOURCE_INPUT')
        result.append(item)
    return result


def parse_junit(path: Path) -> dict:
    raw = path.read_bytes()
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
        raise ValueError('JUNIT_ENTITY_REFUSED')
    root = ET.fromstring(raw)
    if root.tag not in {'testsuite', 'testsuites'}:
        raise ValueError('JUNIT_ROOT_INVALID')
    cases = list(root.iter('testcase'))
    if not cases:
        raise ValueError('NO_EXECUTED_CASES')
    identities = [(c.get('classname'), c.get('name')) for c in cases]
    if len(set(identities)) != len(identities):
        raise ValueError('DUPLICATE_TESTCASE')
    counts = {'total': len(cases), 'passed': 0, 'failed': 0, 'errors': 0, 'skipped': 0}
    for case in cases:
        kinds = [key for key, tag in (('failed', 'failure'), ('errors', 'error'),
                                      ('skipped', 'skipped')) if case.find(tag) is not None]
        if len(kinds) > 1:
            raise ValueError('AMBIGUOUS_TESTCASE_OUTCOME')
        counts[kinds[0] if kinds else 'passed'] += 1
    for suite in root.iter('testsuite'):
        if suite.find('testsuite') is not None:
            continue
        suite_cases = list(suite.iter('testcase'))
        expected = {
            'tests': len(suite_cases),
            'failures': sum(c.find('failure') is not None for c in suite_cases),
            'errors': sum(c.find('error') is not None for c in suite_cases),
            'skipped': sum(c.find('skipped') is not None for c in suite_cases),
        }
        for name, count in expected.items():
            if name in suite.attrib and int(suite.attrib[name]) != count:
                raise ValueError('JUNIT_DECLARED_COUNT_MISMATCH')
    return counts


def live_group_members(group: int) -> list[int]:
    members = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            text = (entry / 'stat').read_text()
            fields = text[text.rfind(')') + 2:].split()
            if int(fields[2]) == group and fields[0] != 'Z':
                members.append(int(entry.name))
        except (OSError, ValueError, IndexError):
            continue
    return members


def run_owned(command: list[str], cwd: Path, env: dict[str, str], prefix: Path,
              timeout: float) -> dict:
    if not timeout > 0:
        raise ValueError('INVALID_TIMEOUT')
    prefix.parent.mkdir(parents=True, exist_ok=True)
    stdout_path = prefix.with_suffix('.stdout.log')
    stderr_path = prefix.with_suffix('.stderr.log')
    started = time.monotonic()
    timed_out = False
    signals = []
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=stdout,
                                   stderr=stderr, start_new_session=True)
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
        finally:
            for sig, grace in ((signal.SIGTERM, 1.0), (signal.SIGKILL, 2.0)):
                if not live_group_members(process.pid):
                    break
                try:
                    os.killpg(process.pid, sig)
                    signals.append(sig.name)
                except ProcessLookupError:
                    break
                deadline = time.monotonic() + grace
                while time.monotonic() < deadline and live_group_members(process.pid):
                    time.sleep(0.02)
            process.wait(timeout=5)
    residue = live_group_members(process.pid)
    return {
        'command': command, 'cwd': str(cwd), 'exit_code': process.returncode,
        'timed_out': timed_out, 'wall_seconds': time.monotonic() - started,
        'pid': process.pid, 'cleanup_signals': signals,
        'process_group_clean': not residue, 'residual_live_pids': residue,
        'stdout_path': str(stdout_path), 'stderr_path': str(stderr_path),
        'stdout_sha256': digest_bytes(stdout_path.read_bytes()),
        'stderr_sha256': digest_bytes(stderr_path.read_bytes()),
    }


def write_json(path: Path, value) -> None:
    if path.exists():
        raise FileExistsError(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def namespace_command(runtime: Path, run: Path, inner: list[str], cpu: int) -> list[str]:
    python = WORKSPACE / '.test-env/bin/python'
    home = run / 'home'
    for directory in (home, home / '.cache', home / '.config', home / '.local/share'):
        directory.mkdir(parents=True, exist_ok=True)
    # Canonical test timing history is a rebuildable projection, never a source edit.
    # The existing lexical destination is over-mounted with run-owned writable bytes.
    timing_source = runtime / 'test_durations.json'
    timing_projection = run / 'test_durations.json'
    if not timing_source.is_file():
        raise ValueError('TIMING_PROJECTION_DESTINATION_UNAVAILABLE')
    if not timing_projection.exists():
        timing_projection.write_bytes(timing_source.read_bytes())
    command = [
        '/usr/bin/bwrap', '--die-with-parent', '--unshare-pid', '--unshare-net',
        '--ro-bind', '/', '/', '--tmpfs', '/home/sikmindz',
        '--ro-bind', str(runtime), str(runtime),
        '--ro-bind', str(WORKSPACE), str(WORKSPACE),
        '--bind', str(run), str(run),
        '--bind', str(timing_projection), str(timing_source), '--tmpfs', '/tmp',
        '--dev', '/dev', '--proc', '/proc', '--clearenv',
    ]
    values = {
        'PATH': f'{python.parent}:/usr/bin:/bin', 'HOME': str(home),
        'HERMES_HOME': str(home / '.ares'), 'XDG_CACHE_HOME': str(home / '.cache'),
        'XDG_CONFIG_HOME': str(home / '.config'), 'XDG_DATA_HOME': str(home / '.local/share'),
        'HERMES_PYTHON': str(python), 'HERMES_TEST_FILE_RETRIES': '0',
        'HERMES_TEST_WORKERS': '1', 'TZ': 'UTC', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
        'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONHASHSEED': '0',
    }
    for key, value in values.items():
        command += ['--setenv', key, value]
    return command + ['--chdir', str(runtime), '--', '/usr/bin/taskset', '-c', str(cpu), *inner]


def collect_fingerprint(runtime: Path) -> dict:
    revision = subprocess.check_output(['git', '-C', str(runtime), 'rev-parse', 'HEAD'], text=True).strip()
    dirty = subprocess.check_output(['git', '-C', str(runtime), 'status', '--porcelain',
                                     '--untracked-files=all'], text=True)
    if dirty.strip():
        raise ValueError('SELECTED_RELEASE_DIRTY')
    paths = subprocess.check_output(['git', '-C', str(runtime), 'ls-files', '-z']).decode().split('\0')
    manifest = hash_paths(runtime, [p for p in paths if p])
    canonical = json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode()
    original_timing_cache = runtime / 'test_durations.json'
    return {'revision': revision, 'tracked_file_count': len(manifest),
            'tracked_manifest_sha256': digest_bytes(canonical), 'tracked_manifest': manifest,
            'production_timing_cache_sha256': digest_bytes(original_timing_cache.read_bytes())}


def run_protocol(run_name: str) -> int:
    protocol_path = WORKSPACE / 'protocol.json'
    protocol = json.loads(protocol_path.read_text())
    runtime = Path(protocol['runtime']).resolve()
    admission_path = WORKSPACE / 'admissions' / 'admission-002' / 'receipt.json'
    admission = json.loads(admission_path.read_text())
    if (admission['exit_code'] != 0 or admission['timed_out'] or not admission['process_group_clean']
            or not admission['protocol_unchanged']
            or admission['protocol_sha256_after'] != digest_bytes(protocol_path.read_bytes())):
        raise ValueError('ADMISSION_NOT_BOUND_TO_CURRENT_PROTOCOL')
    before = collect_fingerprint(runtime)
    if before['revision'] != protocol['expected_revision']:
        raise ValueError('REVISION_MISMATCH')
    if '/' in run_name or run_name in {'', '.', '..'}:
        raise ValueError('INVALID_RUN_NAME')
    run = WORKSPACE / 'runs' / run_name
    run.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    cpu = min(os.sched_getaffinity(0))
    write_json(run / 'source-before.json', before)
    write_json(run / 'protocol.json', protocol)
    write_json(run / 'admission-receipt.json', admission)
    harness_paths = ['benchmark.py', 'micro_worker.py', 'test_benchmark.py', 'protocol.json',
                     '.test-env/lib/python3.14/site-packages/ares_selected_runtime.pth']
    harness_before = hash_paths(WORKSPACE, harness_paths)
    write_json(run / 'harness-before.json', harness_before)
    python = WORKSPACE / '.test-env/bin/python'
    env = {'PATH': '/usr/bin:/bin', 'HOME': str(run / 'home'), 'LANG': 'C.UTF-8'}
    records = []
    for index, file in enumerate(protocol['test_files']):
        remaining = protocol['budget']['total_wall_limit_seconds'] - (time.monotonic() - started)
        if remaining <= 0:
            records.append({'file': file, 'outcome': 'blocked_total_wall_budget'})
            continue
        command = namespace_command(runtime, run, [str(python), '-P', '-m', 'pytest', file,
                            '--collect-only', '-q', '-p', 'no:cacheprovider'], cpu)
        collection = run_owned(command, runtime, env, run / f'collect-{index:02}', min(60, remaining))
        write_json(run / f'collection-{index:02}.json', collection)
        if collection['exit_code'] != 0 or collection['timed_out'] or not collection['process_group_clean']:
            records.append({'file': file, 'outcome': 'blocked_collection', 'collection': collection})
            continue
        collection_output = Path(collection['stdout_path']).read_text()
        collected_ids = [line.strip() for line in collection_output.splitlines()
                         if line.startswith(file + '::')]
        if not collected_ids or len(collected_ids) != len(set(collected_ids)):
            records.append({'file': file, 'outcome': 'invalid_collection_evidence',
                            'collection': collection})
            continue
        collection['collected_case_count'] = len(collected_ids)
        collection['collected_nodeids'] = collected_ids
        junit = run / f'cases-{index:02}.xml'
        command = namespace_command(runtime, run, ['/bin/bash', str(runtime / 'scripts/run_tests.sh'),
                            '-j', '1', '--file-timeout', str(protocol['budget']['file_timeout_seconds']),
                            '--file-retries', '0', file, '--', '-q', '-p', 'no:cacheprovider',
                            f'--junitxml={junit}'], cpu)
        remaining = protocol['budget']['total_wall_limit_seconds'] - (time.monotonic() - started)
        if remaining <= 0:
            records.append({'file': file, 'outcome': 'blocked_total_wall_budget', 'collection': collection})
            continue
        execution = run_owned(command, runtime, env, run / f'execution-{index:02}',
                              min(protocol['budget']['file_timeout_seconds'] + 60, remaining))
        record = {'file': file, 'collection': collection, 'execution': execution}
        try:
            record['cases'] = parse_junit(junit)
            c = record['cases']
            passed = (execution['exit_code'] == 0 and not execution['timed_out']
                      and execution['process_group_clean'] and c['total'] > 0
                      and c['total'] == collection['collected_case_count']
                      and c['failed'] == c['errors'] == c['skipped'] == 0)
            record['outcome'] = 'passed' if passed else 'failed'
            record['junit_sha256'] = digest_bytes(junit.read_bytes())
        except (OSError, ValueError, ET.ParseError) as error:
            record.update(outcome='invalid_evidence', evidence_error=str(error))
        write_json(run / f'file-{index:02}.json', record)
        records.append(record)
        print(json.dumps({'file': file, 'outcome': record['outcome'], 'cases': record.get('cases')}), flush=True)
    micro_output = run / 'microperformance.json'
    remaining = protocol['budget']['total_wall_limit_seconds'] - (time.monotonic() - started)
    if remaining > 0:
        command = namespace_command(runtime, run, [str(python), '-P', str(WORKSPACE / 'micro_worker.py'),
                                                   str(protocol_path), str(micro_output)], cpu)
        micro = run_owned(command, runtime, env, run / 'micro-worker', min(180, remaining))
        write_json(run / 'micro-worker.json', micro)
    else:
        micro = {'exit_code': None, 'timed_out': False, 'process_group_clean': True,
                 'outcome': 'blocked_total_wall_budget'}
    after = collect_fingerprint(runtime)
    write_json(run / 'source-after.json', after)
    unchanged = (before['tracked_manifest_sha256'] == after['tracked_manifest_sha256']
                 and before['production_timing_cache_sha256'] == after['production_timing_cache_sha256'])
    harness_after = hash_paths(WORKSPACE, harness_paths)
    write_json(run / 'harness-after.json', harness_after)
    harness_unchanged = harness_before == harness_after
    total = {'total': 0, 'passed': 0, 'failed': 0, 'errors': 0, 'skipped': 0}
    for record in records:
        for key in total:
            total[key] += record.get('cases', {}).get(key, 0)
    success = (len(records) == len(protocol['test_files']) and all(r['outcome'] == 'passed' for r in records)
               and unchanged and harness_unchanged and micro.get('exit_code') == 0 and not micro['timed_out']
               and micro['process_group_clean'] and micro_output.exists())
    summary = {
        'schema': 'AresOfflineRuntimeBenchmarkResultV1', 'registered_track_complete': success,
        'full_evaluation_programme_complete': False, 'runtime': str(runtime),
        'revision': before['revision'], 'source_unchanged': unchanged,
        'harness_unchanged': harness_unchanged,
        'source_manifest_sha256': before['tracked_manifest_sha256'],
        'protocol_sha256': digest_bytes(protocol_path.read_bytes()),
        'files': records, 'conformance_cases': total, 'micro_worker': micro,
        'provider_calls': 0, 'paid_inference_usd': 0,
        'wall_seconds': time.monotonic() - started, 'cpu_affinity': [cpu],
        'completed_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'blocked_programme_lanes': protocol['remaining_programme_gates'],
        'scope': 'selected-release source conformance; fixture owner callbacks are not authenticated live-service proof',
    }
    write_json(run / 'summary.json', summary)
    print(json.dumps({k: summary[k] for k in ('registered_track_complete', 'full_evaluation_programme_complete',
                      'revision', 'source_unchanged', 'conformance_cases', 'wall_seconds')}, indent=2))
    return 0 if success else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-name', required=True)
    args = parser.parse_args()
    raise SystemExit(run_protocol(args.run_name))
