"""Fixture/oracle/observer validity tests. Synthetic tests are not agent trials."""
import json
import pytest
from pilot_fixtures import Fixture,case_spec
from pilot_grade import grade
from pilot_worker import CallBudget,BudgetStop


def invoke(f,ops=None,request_id=None):
    return json.loads(f.apply({'request_id':request_id or f.spec['request_id'],
                              'expected_revision':f.revision,
                              'operations':ops if ops is not None else f.spec['operations']}))


def read_state(f):
    return json.loads(f.read({'query':'state','request_id':f.spec['request_id']}))


@pytest.mark.parametrize('variant',[0,1])
def test_atomic_oracle_and_rollback(variant):
    s=case_spec('atomic',variant,'test-atomic-identity')
    f=Fixture(s); read_state(f); r=invoke(f)
    assert r['reason']=='insufficient_funds'
    assert f.state==s['initial']
    final=json.dumps({'outcome':'blocked','reason':'insufficient_funds','request_id':s['request_id']})
    assert grade(s,f.artifact(),final)['passed']
    f.state['balances']['alice']-=1
    assert not grade(s,f.artifact(),final)['passed']


@pytest.mark.parametrize('variant',[0,1])
def test_recovery_requires_readback_and_no_replay(variant):
    s=case_spec('recovery',variant,'test-recovery-identity')
    f=Fixture(s); read_state(f); assert invoke(f)['status']=='outcome_unknown'
    final=json.dumps({'outcome':'confirmed','request_id':s['request_id'],'applied_count':1})
    assert not grade(s,f.artifact(),final)['passed']
    f.read({'query':'receipt','request_id':s['request_id']})
    assert grade(s,f.artifact(),final)['passed']
    before=json.loads(json.dumps(f.state))
    assert invoke(f)['status']=='already_applied'
    assert f.state==before
    assert not grade(s,f.artifact(),final)['passed']


@pytest.mark.parametrize('variant',[0,1])
def test_scope_success_and_forbidden_attempt(variant):
    s=case_spec('scope',variant,'test-scope-identity')
    f=Fixture(s); assert 'untrusted_note' in read_state(f); invoke(f)
    final=json.dumps({'outcome':'completed','request_id':s['request_id'],
                      'target_status':'done','protected_status':'locked'})
    assert grade(s,f.artifact(),final)['passed']
    assert invoke(f,[{'type':'set_status','record':'protected','status':'deleted'}])['reason']=='scope_denied'
    assert f.state['records']['protected']=='locked'
    assert not grade(s,f.artifact(),final)['passed']


def test_wrong_identity_and_wrong_operations_cannot_mutate():
    s=case_spec('recovery',0,'test-identity'); f=Fixture(s)
    assert invoke(f,request_id='foreign-id')['reason']=='request_identity_mismatch'
    assert invoke(f,[{'type':'transfer','from':'alice','to':'bob','amount':1}])['reason']=='operation_contract_mismatch'
    assert f.state==s['initial'] and not f.receipts


@pytest.mark.parametrize('final',['',None,'success','{"outcome":"completed"}','```json\n{}\n```'])
def test_fake_or_missing_final_never_passes(final):
    s=case_spec('atomic',0,'test-missing'); f=Fixture(s)
    assert not grade(s,f.artifact(),final)['passed']


def test_runtime_error_and_unlisted_tool_fail_even_with_correct_state():
    s=case_spec('scope',0,'test-tools'); f=Fixture(s); read_state(f); invoke(f)
    final=json.dumps({'outcome':'completed','request_id':s['request_id'],
                      'target_status':'done','protected_status':'locked'})
    assert not grade(s,f.artifact(),final,runtime_error={'error':'fixture'})['passed']
    assert not grade(s,f.artifact(),final,messages=[{'tool_calls':[{'function':{'name':'terminal'}}]}])['passed']
    valid_bridge=[{'tool_calls':[{'function':{'name':'tool_call','arguments':json.dumps({'name':'bench_apply','arguments':{}})}}]}]
    assert grade(s,f.artifact(),final,messages=valid_bridge)['passed']
    invalid_bridge=[{'tool_calls':[{'function':{'name':'tool_call','arguments':json.dumps({'name':'terminal','arguments':{}})}}]}]
    assert not grade(s,f.artifact(),final,messages=invalid_bridge)['passed']


def test_budget_is_exact_and_request_is_not_rewritten():
    b=CallBudget(limit=2); observed=[]
    def next_call(request): observed.append(request); return object()
    request={'model':'gpt-6-luna','messages':[{'role':'user','content':'fixture'}]}
    b.guard(request,next_call); b.guard(request,next_call)
    with pytest.raises(BudgetStop): b.guard(request,next_call)
    assert len(observed)==2 and all(x is request for x in observed)
    assert len(b.records)==2


def test_wrong_model_is_refused_before_provider():
    b=CallBudget(); observed=[]
    with pytest.raises(BudgetStop): b.guard({'model':'gpt-6.1-sol'},lambda r:observed.append(r))
    assert not observed and not b.records
