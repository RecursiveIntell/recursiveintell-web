"""One fresh diagnostic recovery trial after correcting the observer.

Conservatively charge all 30 old observer entries against the 40-call
allowance, despite nested overcount. Permit at most eight new dispatches.
No old result or frozen harness is edited. This is not a six-task rerun.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from pilot_controller import collect_fingerprint, SOURCE, WORKSPACE
from pilot_fixtures import case_spec
from benchmark import run_owned, write_json


def execute():
    prior = WORKSPACE / 'runs/local-tool-pilot-001'
    prior_summary = json.loads((prior / 'summary.json').read_text())
    charged = prior_summary['scheduled_provider_calls']
    assert charged == 30 and charged + 8 <= 40
    run = WORKSPACE / 'runs/local-tool-followup-001'
    run.mkdir(exist_ok=False)
    before = collect_fingerprint(SOURCE)
    write_json(run / 'source-before.json', before)
    frozen = run / 'frozen-harness'
    frozen.mkdir()
    files = ['pilot_worker.py', 'pilot_fixtures.py', 'pilot_grade.py',
             'pilot_controller.py', 'followup_controller.py', 'test_pilot.py',
             'test_counter_followup.py']
    hashes = {}
    for name in files:
        shutil.copy2(ROOT / name, frozen / name)
        hashes[name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    write_json(run / 'harness-before.json', hashes)
    # The task and grader have not changed since the first attempt.
    old_hashes = json.loads((prior / 'harness-before.json').read_text())
    assert all(old_hashes[n] == hashes[n] for n in ['pilot_fixtures.py', 'pilot_grade.py'])
    case_id = 'recovery-followup-' + uuid.uuid4().hex[:12]
    spec = case_spec('recovery', 0, case_id)
    write_json(run / 'spec.json', spec)
    protocol = {
        'schema': 'AresLocalDiagnosticFollowupProtocolV1',
        'model': 'gpt-6-luna', 'provider': 'openai-codex', 'reasoning_effort': 'high',
        'source_revision': before['revision'], 'registered_trials': 1,
        'family': 'recovery', 'variant': 0, 'prior_run': str(prior),
        'prior_conservatively_charged_entries': charged, 'trial_call_limit': 8,
        'authorized_total_call_limit': 40, 'trial_hard_wall_seconds': 300,
        'correction': 'Observe only canonical _interruptible_api_call; stock Codex streaming forwards to it.',
        'changed_inputs': ['observer implementation', 'call limit', 'fresh request ID'],
        'unchanged_inputs': ['runtime source', 'fixture task definitions', 'grader', 'model', 'reasoning effort'],
        'separate_attempt_not_pooled_with_original': True,
        'not_official_deeprsi': True, 'not_as_shipped_full_runtime': True,
        'fixtures_only': True, 'memory_and_identity_loading': False,
        'sdk_internal_retries_independently_counted': False,
        'operator_correction': 'forget the damn email.  i just want my benchmark ran',
        'outreach_cancelled': True,
    }
    write_json(run / 'protocol.json', protocol)
    env = {'HOME': '/home/sikmindz', 'HERMES_HOME': '/home/sikmindz/.ares',
           'PATH': str(SOURCE / '.venv/bin') + ':/usr/bin:/bin',
           'PYTHONPATH': str(SOURCE) + ':' + str(ROOT) + ':' + str(WORKSPACE),
           'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
           'LANG': 'C.UTF-8', 'TZ': 'UTC'}
    started = time.monotonic()
    command = [str(SOURCE / '.venv/bin/python'), '-P', str(ROOT / 'pilot_worker.py'),
               '--spec', str(run / 'spec.json'), '--output', str(run / 'trial'),
               '--call-limit', '8']
    control = run_owned(command, ROOT, env, run / 'worker-0', 300)
    write_json(run / 'worker-0-controller.json', control)
    after = collect_fingerprint(SOURCE)
    write_json(run / 'source-after.json', after)
    hashes_after = {n: hashlib.sha256((ROOT / n).read_bytes()).hexdigest() for n in files}
    write_json(run / 'harness-after.json', hashes_after)
    trial = json.loads((run / 'trial/trial.json').read_text())
    used = trial['scheduled_provider_calls']
    assert used <= 8 and charged + used <= 40
    intact = before == after and hashes == hashes_after and trial['inputs_unchanged']
    passed = (trial['grade']['passed'] and intact and control['exit_code'] == 0
              and not control['timed_out'] and control['process_group_clean'])
    summary = {'schema': 'AresLocalDiagnosticFollowupSummaryV1', 'run': str(run),
               'registered_trials': 1, 'passed_trials': int(passed),
               'failed_or_blocked_trials': int(not passed),
               'scheduled_provider_calls': used, 'prior_conservative_charge': charged,
               'combined_conservative_charge': charged + used,
               'remaining_scheduled_allowance': 40 - charged - used,
               'agent_usage': trial['agent_usage'], 'grade': trial['grade'],
               'failure': trial.get('failure'), 'source_and_harness_unchanged': intact,
               'process_group_clean': control['process_group_clean'],
               'not_official_deeprsi': True, 'full_programme_complete': False,
               'wall_seconds': time.monotonic() - started,
               'completed_at': datetime.now(timezone.utc).isoformat()}
    write_json(run / 'summary.json', summary)
    print(json.dumps(summary, indent=2), flush=True)
    return 0 if intact and control['process_group_clean'] else 1


if __name__ == '__main__':
    raise SystemExit(execute())
