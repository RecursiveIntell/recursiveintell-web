"""Actual AIAgent worker. Only fixture handlers are exposed; no model mocking."""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import hashlib
import json
import logging
import os
from pathlib import Path
import sys
import threading
import time

SOURCE=Path('/home/sikmindz/.ares/runtime/releases/56caa3efc0854a527b125ba34c964ebce437b8ad/source')
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(SOURCE))
sys.path.insert(1,str(ROOT))
from pilot_fixtures import Fixture,TOOLSET,TOOL_NAMES,definitions,task_prompt
from pilot_grade import grade


class BudgetStop(BaseException):
    """Fail-closed cancellation: middleware's generic Exception fallback cannot swallow it."""


class CallBudget:
    def __init__(self,limit=5,seconds=240):
        self.limit=limit
        self.deadline=time.monotonic()+seconds
        self.records=[]
        self.lock=threading.Lock()

    def guard(self,request,next_call,**context):
        with self.lock:
            if len(self.records)>=self.limit or time.monotonic()>=self.deadline:
                raise BudgetStop('BENCHMARK_CALL_OR_WALL_BUDGET_EXHAUSTED')
            if request.get('model')!='gpt-6-luna':
                raise BudgetStop('UNAUTHORIZED_MODEL_ROUTE')
            event={'ordinal':len(self.records)+1,'requested_model':request.get('model'),
                   'returned':False,'dispatch_layer':'Ares interruptible provider execution'}
            self.records.append(event)
        try:
            response=next_call(request)
            event['returned']=True
            served=getattr(response,'model',None)
            if isinstance(served,str): event['served_model']=served
            return response
        except BaseException as error:
            event['error_class']=type(error).__name__
            raise


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clean(value):
    from agent.redact import redact_sensitive_text
    if isinstance(value,dict):
        return {k:clean(v) for k,v in value.items() if k not in {
            'reasoning_content','reasoning','thinking','analysis','api_key','access_token','refresh_token'}}
    if isinstance(value,list): return [clean(v) for v in value]
    if isinstance(value,str): return redact_sensitive_text(value)
    if value is None or isinstance(value,(bool,int,float)): return value
    return {'object_type':type(value).__name__}


def execute(spec_path,output,admission_only=False):
    output=Path(output)
    output.mkdir(parents=True,exist_ok=False)
    spec=json.loads(Path(spec_path).read_text())
    fixture=Fixture(spec)
    started=time.monotonic()
    record={'schema':'AresControlledToolTrialV1','source':str(SOURCE),
            'source_revision':'56caa3efc0854a527b125ba34c964ebce437b8ad',
            'model':'gpt-6-luna','provider':'openai-codex','reasoning_effort':'high',
            'api_mode':'codex_responses','spec':spec,'started_at':datetime.now(timezone.utc).isoformat(),
            'not_official_deeprsi':True,'fixture_effects_only':True,'admission_only':admission_only,
            'credentials_not_copied_to_fixture_state':True,'caller_token_store_reads':0,
            'physical_sdk_retry_count':'not exposed by this observer'}
    inputs=[Path(__file__).resolve(),ROOT/'pilot_fixtures.py',ROOT/'pilot_grade.py',
            SOURCE/'run_agent.py',SOURCE/'agent/conversation_loop.py',SOURCE/'agent/agent_init.py',
            SOURCE/'model_tools.py',SOURCE/'tools/registry.py',SOURCE/'hermes_cli/middleware.py']
    record['input_hashes_before']={str(p):hash_file(p) for p in inputs}
    agent=None
    db=None
    budget=CallBudget()
    result={}
    error=None
    phase='imports'
    try:
        logging.getLogger().setLevel(logging.ERROR)
        from tools.registry import registry
        from run_agent import AIAgent
        from hermes_state import SessionDB

        phase='register_fixture_tools'
        for definition in definitions():
            handler=fixture.read if definition['name']=='bench_read' else fixture.apply
            registry.register(name=definition['name'],toolset=TOOLSET,schema=definition,
                              handler=handler,check_fn=lambda:True)

        phase='initialize_agent'
        db=SessionDB(db_path=output/'state.db')
        agent=AIAgent(model='gpt-6-luna',provider='openai-codex',api_mode='codex_responses',
                      enabled_toolsets=[TOOLSET],max_iterations=5,max_tokens=2048,
                      reasoning_config={'enabled':True,'effort':'high'},
                      skip_context_files=True,skip_memory=True,skip_background_review=True,
                      load_soul_identity=False,quiet_mode=True,save_trajectories=False,
                      session_id='ares-bench-'+spec['request_id'],session_db=db,
                      run_budget_seconds=240,fallback_model={})
        exposed={t['function']['name'] for t in agent.tools}
        record['observed_tool_names']=sorted(exposed)
        record['observed_valid_tool_names']=sorted(agent.valid_tool_names)
        record['observed_route']={'model':agent.model,'provider':agent.provider,'api_mode':agent.api_mode}
        from model_tools import get_tool_definitions,handle_function_call
        catalog=get_tool_definitions(enabled_toolsets=[TOOLSET],quiet_mode=True,skip_tool_search_assembly=True)
        catalog_names={t['function']['name'] for t in catalog}
        record['effective_fixture_catalog_names']=sorted(catalog_names)
        bridge={'tool_search','tool_describe','tool_call'}
        if catalog_names!=TOOL_NAMES or exposed not in (TOOL_NAMES,bridge) or agent.valid_tool_names!=exposed:
            raise BudgetStop('FIXTURE_TOOL_ALLOWLIST_NOT_EXACT')
        if exposed==bridge:
            call_schema=next(t['function'] for t in agent.tools if t['function']['name']=='tool_call')
            if not {'name','arguments'}<=set(call_schema['parameters']['properties']):
                raise BudgetStop('DEFERRED_BRIDGE_SCHEMA_NOT_QUALIFIED')
            canary_hits=[]
            def forbidden_canary(args,**kwargs):
                canary_hits.append(True)
                return json.dumps({'error':'outside-catalog canary must never execute'})
            registry.register(name='bench_outside_canary',toolset='ares_benchmark_forbidden',
                schema={'name':'bench_outside_canary','description':'Inert out-of-scope admission witness',
                        'parameters':{'type':'object','properties':{},'additionalProperties':False}},
                handler=forbidden_canary,check_fn=lambda:True)
            denied=handle_function_call('tool_call',{'name':'bench_outside_canary','arguments':{}},
                session_id=agent.session_id,enabled_tools=sorted(exposed),enabled_toolsets=[TOOLSET])
            record['deferred_bridge_negative_witness']={'canary_executed':bool(canary_hits),
                                                       'denial_result':clean(denied)}
            registry.deregister('bench_outside_canary')
            if canary_hits or 'error' not in str(denied).lower():
                raise BudgetStop('DEFERRED_BRIDGE_SCOPE_DENIAL_NOT_PROVEN')
        if agent.provider!='openai-codex' or agent.model!='gpt-6-luna' or agent.api_mode!='codex_responses':
            raise BudgetStop('ACTUAL_AGENT_ROUTE_MISMATCH')
        if getattr(agent,'_fallback_chain',None):
            raise BudgetStop('UNREGISTERED_FALLBACK_ROUTE')
        # Instance-local measurement/cancellation wrappers. They forward the
        # exact request to Ares's unchanged provider execution methods. No
        # provider response, prompt, tool argument or runtime source is replaced.
        for method_name in ('_interruptible_api_call','_interruptible_streaming_api_call'):
            original=getattr(agent,method_name)
            def measured(request,*args,_original=original,**kwargs):
                return budget.guard(request,lambda same_request:_original(same_request,*args,**kwargs))
            setattr(agent,method_name,measured)
        record['call_budget_instrumentation']='instance-local transparent provider-call wrappers'
        record['actual_tool_names']=sorted(exposed)
        record['actual_agent_class']=type(agent).__name__
        record['actual_agent_module']=sys.modules[type(agent).__module__].__file__
        if admission_only:
            record['status']='passed_local_tool_and_route_admission'
        else:
            phase='actual_run_conversation'
            result=agent.run_conversation(task_prompt(spec),task_id=spec['request_id'])
            if not isinstance(result,dict): raise TypeError('AGENT_RESULT_NOT_OBJECT')
            error=result.get('error')
            if result.get('completed') is False or result.get('partial') is True:
                error=error or {'agent_completion_state':'blocked_or_partial'}
            record['status']='executed'
    except BaseException as exc:
        error={'phase':phase,'error_class':type(exc).__name__}
        if isinstance(exc,BudgetStop): error['reason']=str(exc)
        record['status']='blocked_or_failed'
        record['failure']=error
    finally:
        record['fixture']=fixture.artifact()
        record['call_observer']=budget.records
        record['scheduled_provider_calls']=len(budget.records)
        record['agent_result']=clean(result)
        if agent is not None:
            fields=['session_api_calls','session_input_tokens','session_output_tokens',
                    'session_cache_read_tokens','session_reasoning_tokens','session_total_tokens']
            record['agent_usage']={key:getattr(agent,key,None) for key in fields}
            try: agent.close(); record['agent_close']='returned'
            except Exception as exc: record['agent_close']='failed:'+type(exc).__name__
        if db is not None:
            try: db.close(); record['session_db_close']='returned'
            except Exception as exc: record['session_db_close']='failed:'+type(exc).__name__
        record['input_hashes_after']={str(p):hash_file(p) for p in inputs}
        record['inputs_unchanged']=record['input_hashes_before']==record['input_hashes_after']
        record['wall_seconds']=time.monotonic()-started
        record['completed_at']=datetime.now(timezone.utc).isoformat()
        if not admission_only:
            record['grade']=grade(spec,record['fixture'],result.get('final_response'),
                                  runtime_error=error,messages=result.get('messages'))
            if not record['scheduled_provider_calls'] or not any(x['returned'] for x in budget.records):
                record['grade']['passed']=False
                record['grade']['failed_checks'].append('no_observed_returned_provider_execution')
        with (output/'trial.json').open('x') as handle:
            json.dump(record,handle,indent=2,sort_keys=True); handle.write('\n')
    print(json.dumps({'output':str(output/'trial.json'),'status':record['status'],
                      'scheduled_provider_calls':record['scheduled_provider_calls'],
                      'usage':record.get('agent_usage'),'grade':record.get('grade'),
                      'failure':record.get('failure'),'wall_seconds':record['wall_seconds']},indent=2))
    return 0 if record['status'] in {'executed','passed_local_tool_and_route_admission'} and record['inputs_unchanged'] else 1


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--spec',required=True)
    parser.add_argument('--output',required=True)
    parser.add_argument('--admission-only',action='store_true')
    args=parser.parse_args()
    raise SystemExit(execute(args.spec,args.output,args.admission_only))
