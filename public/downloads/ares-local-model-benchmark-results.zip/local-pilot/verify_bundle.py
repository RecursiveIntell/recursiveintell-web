"""Offline verification of the evidence bundle; no model/provider calls."""
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / 'manifest.json').read_text())
for name, info in manifest['files'].items():
    data = (ROOT / name).read_bytes()
    assert len(data) == info['bytes']
    assert hashlib.sha256(data).hexdigest() == info['sha256']

for run_name, paths in [('local-tool-pilot-001', manifest['original_trial_paths']),
                        ('local-tool-followup-001', ['runs/local-tool-followup-001/trial/trial.json'])]:
    spec = importlib.util.spec_from_file_location('bundle_oracle', ROOT / 'runs' / run_name / 'frozen-harness/pilot_grade.py')
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    for name in paths:
        trial = json.loads((ROOT / name).read_text())
        result = trial.get('agent_result') or {}
        error = trial.get('failure') or result.get('error')
        if result.get('completed') is False or result.get('partial') is True:
            error = error or {'agent_completion_state': 'blocked_or_partial'}
        replay = oracle.grade(trial['spec'], trial['fixture'], result.get('final_response'),
                              runtime_error=error, messages=result.get('messages'))
        assert replay == trial['grade'], name
        if run_name == 'local-tool-pilot-001':
            assert not replay['passed']
        else:
            assert replay['passed']

print(json.dumps({'bundle_verified': True, 'file_count': len(manifest['files']),
                  'original_trials_replayed': len(manifest['original_trial_paths']),
                  'followup_trials_replayed': 1, 'official_deeprsi_score': False,
                  'model_calls_made_by_verification': 0}, indent=2))
