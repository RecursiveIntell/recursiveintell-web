"""Package inspected safe evidence and verify the delivered archive itself."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import zipfile

ROOT = Path('/home/sikmindz/work/ares-benchmark-program')
PACK = ROOT / 'runs/local-model-evidence-bundle-001'
PRIVATE_KEYS = {'reasoning', 'reasoning_content', 'thinking', 'analysis',
                'reasoning_details', 'codex_reasoning_items',
                'api_key', 'access_token', 'refresh_token'}


def load(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, obj):
    with p.open('x') as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write('\n')


def main():
    closeout = ROOT / 'runs/local-model-closeout-002'
    review = ROOT / 'reviews/local-model-closeout-public-001'
    panel = load(review / 'panel.json')
    verified = load(review / 'verification.json')
    outcome = panel['results'][0]
    assert panel['required_profiles'] == ['public']
    assert outcome['outcome'] == 'returned' and outcome['exit_code'] == 0
    assert outcome['cleanup_state'] == 'clean' and verified['execution_artifacts_verified']
    report = (review / 'profiles/public.stdout.txt').read_text()
    assert report.startswith('ACCEPT') and 'not independently inspected here' in report
    sid = outcome['session_id']
    with sqlite3.connect('file:' + str(review / 'session-state/public/state.db') + '?mode=ro', uri=True) as c:
        c.row_factory = sqlite3.Row
        rows = [dict(x) for x in c.execute('SELECT id,model,api_call_count,tool_call_count,input_tokens,output_tokens,cache_read_tokens,reasoning_tokens,archived FROM sessions WHERE id=?', (sid,))]
    assert len(rows) == 1
    usage = rows[0]
    assert usage['model'] == 'gpt-6-luna' and usage['api_call_count'] == 1
    assert usage['tool_call_count'] == 0 and usage['archived'] == 1
    result = load(closeout / 'verification.json')
    conservative = result['combined_conservative_budget_charge'] + usage['api_call_count']
    assert conservative == 37 and conservative <= 40
    integration = {'schema': 'AresLocalModelPublicReviewIntegrationV1',
        'verified_at': datetime.now(timezone.utc).isoformat(),
        'review_receipt': str(review / 'panel.json'), 'profile': 'public',
        'outcome': 'ACCEPT_SCOPED_WORDING', 'review_is_brief_based_not_raw_artifact_replication': True,
        'execution_artifacts_verified': True, 'controller_semantic_review_complete': True,
        'retained_qualifiers': ['six initial attempts measurement-invalid', 'one valid recovery diagnostic only',
            'not official DeepRSI', 'not full programme', 'not as-shipped full runtime',
            'no superiority or recursive-self-improvement inference', 'not independent scientific validation',
            'no wire-level or dollar-cost claims'],
        'review_usage': usage, 'review_reasoning_effort': outcome['reasoning_effort'],
        'conservative_trial_plus_closeout_charge': conservative, 'trial_budget_cap': 40,
        'publication_authorized': False, 'email_sent': False,
        'report_sha256': sha(ROOT / 'LOCAL-MODEL-RESULTS.md'),
        'review_stdout_sha256': sha(review / 'profiles/public.stdout.txt')}
    save(closeout / 'public-review-integration.json', integration)
    PACK.mkdir(exist_ok=False)
    removed = []
    projections = []
    def clean(v, path=''):
        if isinstance(v, dict):
            answer = {}
            for k, x in v.items():
                if k in PRIVATE_KEYS:
                    removed.append(path + '/' + k)
                else:
                    answer[k] = clean(x, path + '/' + k)
            return answer
        if isinstance(v, list):
            return [clean(x, path + '/' + str(i)) for i, x in enumerate(v)]
        return v
    selected = [ROOT / 'LOCAL-MODEL-RESULTS.md',
                ROOT / 'authorization-20261014.json', ROOT / 'authorization-pilot-larger-20261014.json']
    for run_name in ['local-tool-pilot-001', 'local-tool-followup-001']:
        run = ROOT / 'runs' / run_name
        selected += [p for p in run.rglob('*') if p.is_file() and p.suffix in {'.json', '.py', '.log'}
                     and '__pycache__' not in p.parts]
    selected += list(closeout.glob('*.json'))
    selected += [review / 'panel.json', review / 'verification.json',
                 review / 'profiles/public.stdout.txt', review / 'profiles/public.stderr.txt']
    selected += [ROOT / 'local-pilot' / n for n in ['verify_closeout.py', 'verify_pilot.py',
        'verify_bundle.py', 'build_result_bundle.py', 'observer-tests-003.xml']]
    selected.append(ROOT / 'benchmark.py')
    seen = set()
    for source in selected:
        rel = str(source.relative_to(ROOT))
        if rel in seen: continue
        seen.add(rel)
        target = PACK / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if source.suffix == '.json':
            removed = []
            value = clean(load(source))
            if removed:
                save(target, value)
                projections.append({'path': rel, 'original_sha256': sha(source),
                                    'projection_sha256': sha(target),
                                    'removed_private_field_paths': removed,
                                    'policy': 'omit_private_reasoning_and_credential_fields_v1'})
            else:
                shutil.copy2(source, target)
        else:
            shutil.copy2(source, target)
    shutil.copy2(ROOT / 'local-pilot/verify_bundle.py', PACK / 'verify_bundle.py')
    save(PACK / 'projection-lineage.json', projections)
    files = {str(p.relative_to(PACK)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
             for p in PACK.rglob('*') if p.is_file()}
    original_paths = sorted(str(p.relative_to(PACK)) for p in (PACK / 'runs/local-tool-pilot-001').glob('*/trial.json'))
    assert len(original_paths) == 6
    manifest = {'schema': 'AresLocalModelEvidenceBundleManifestV1',
        'created_at': datetime.now(timezone.utc).isoformat(), 'files': files,
        'original_trial_paths': original_paths,
        'private_session_databases_excluded': True,
        'projection_lineage': 'projection-lineage.json',
        'not_official_deeprsi': True}
    save(PACK / 'manifest.json', manifest)
    verify = subprocess.run([sys.executable, '-P', str(PACK / 'verify_bundle.py')],
                            text=True, capture_output=True, check=False)
    assert verify.returncode == 0, verify.stderr
    offline = json.loads(verify.stdout)
    archive = ROOT / 'ares-local-model-benchmark-results.zip'
    assert not archive.exists()
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(PACK.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:
                z.write(p, str(p.relative_to(PACK)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        names = z.namelist()
        assert len(names) == len(set(names)) == len(files) + 1
        for name, info in files.items():
            data = z.read(name)
            assert len(data) == info['bytes'] and hashlib.sha256(data).hexdigest() == info['sha256']
        assert not any(n.endswith(('.db', '.db-wal', '.db-shm')) for n in names)
        for name in names:
            if name.endswith('.json'):
                removed = []
                clean(json.loads(z.read(name)))
                assert not removed, name
    receipt = {'schema': 'AresLocalModelDeliverableVerificationV1',
        'verified_at': datetime.now(timezone.utc).isoformat(), 'verified': True,
        'archive': str(archive), 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
        'archive_file_count': len(names), 'archive_crc_and_manifest_hashes_verified': True,
        'private_session_databases_excluded': True, 'private_field_projection_count': len(projections),
        'standalone_offline_oracle_replay': offline,
        'public_review_controller_integrated': True,
        'conservative_trial_plus_closeout_charge': conservative,
        'no_external_publication_or_email': True}
    save(closeout / 'deliverable-verification.json', receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
