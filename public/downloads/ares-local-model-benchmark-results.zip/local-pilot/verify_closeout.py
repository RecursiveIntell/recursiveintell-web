"""Read-only reconciliation of failed pilot and separately registered followup.

The oracle is re-executed from each frozen harness. This is a controller
verification, not independent scientific replication. Hidden reasoning and
credential fields are never selected from the session stores.
"""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path('/home/sikmindz/work/ares-benchmark-program')


def load(p):
    return json.loads(p.read_text())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def write(p, obj):
    with p.open('x') as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write('\n')


def transcript(db):
    with sqlite3.connect('file:' + str(db) + '?mode=ro', uri=True) as c:
        c.row_factory = sqlite3.Row
        return [dict(row) for row in c.execute(
            'SELECT role,content,tool_name,tool_calls,tool_call_id FROM messages ORDER BY id')]


def execute(out_dir=None):
    old = ROOT / 'runs/local-tool-pilot-001'
    new = ROOT / 'runs/local-tool-followup-001'
    out = Path(out_dir) if out_dir else ROOT / 'runs/local-model-closeout-001'
    out.mkdir(exist_ok=False)
    old_verification = load(old / 'verification-001.json')
    assert old_verification['verified'] is True
    old_summary = load(old / 'summary.json')
    registered = load(old / 'registered-cases.json')
    assert len(registered) == len(old_summary['results']) == 6
    original_rows = []
    for i, case in enumerate(registered):
        trial_path = old / case['case_id'] / 'trial.json'
        trial = load(trial_path)
        assert sha(trial_path) == old_verification['per_trial'][i]['trial_sha256']
        assert trial['spec'] == case['spec']
        assert trial['status'] == 'blocked_or_failed'
        assert trial['failure']['error_class'] == 'BudgetStop'
        assert trial['failure']['reason'] == 'BENCHMARK_CALL_OR_WALL_BUDGET_EXHAUSTED'
        messages = transcript(trial_path.parent / 'state.db')
        write(out / (case['case_id'] + '-public-transcript.json'), messages)
        original_rows.append({'case_id': case['case_id'], 'family': case['spec']['family'],
            'variant': case['spec']['variant'], 'graded_pass': trial['grade']['passed'],
            'observer_entries': trial['scheduled_provider_calls'],
            'agent_reported_calls': trial['agent_usage']['session_api_calls'],
            'apply_attempts': trial['grade']['defining_actions']['apply_attempts'],
            'failure': trial['failure'], 'trial_sha256': sha(trial_path)})
    assert all(r['graded_pass'] is False for r in original_rows)
    protocol = load(new / 'protocol.json')
    summary = load(new / 'summary.json')
    assert protocol['registered_trials'] == 1
    assert protocol['prior_conservatively_charged_entries'] == 30
    hashes = load(new / 'harness-before.json')
    assert hashes == load(new / 'harness-after.json')
    for name, digest in hashes.items():
        assert sha(new / 'frozen-harness' / name) == digest
    before = load(new / 'source-before.json')
    assert before == load(new / 'source-after.json')
    assert before['revision'] == protocol['source_revision']
    old_hashes = load(old / 'harness-before.json')
    assert all(hashes[n] == old_hashes[n] for n in ['pilot_fixtures.py', 'pilot_grade.py'])
    path = new / 'trial/trial.json'
    trial = load(path)
    spec = load(new / 'spec.json')
    assert trial['spec'] == spec
    assert trial['input_hashes_before'] == trial['input_hashes_after']
    for n in ['pilot_worker.py', 'pilot_fixtures.py', 'pilot_grade.py']:
        assert [v for k, v in trial['input_hashes_before'].items() if Path(k).name == n] == [hashes[n]]
    assert trial['model'] == 'gpt-6-luna' and trial['provider'] == 'openai-codex'
    assert trial['call_budget_instrumentation'].startswith('single canonical codex nonstreaming seam;')
    assert trial['effective_fixture_catalog_names'] == ['bench_apply', 'bench_read']
    witness = trial.get('deferred_bridge_negative_witness')
    if witness:
        assert not witness['canary_executed'] and 'error' in str(witness['denial_result']).lower()
    used = trial['scheduled_provider_calls']
    assert 0 < used <= 8 and used == len(trial['call_observer'])
    assert all(e['ordinal'] == i+1 and e['requested_model'] == 'gpt-6-luna'
               for i, e in enumerate(trial['call_observer']))
    assert summary['scheduled_provider_calls'] == used
    assert summary['combined_conservative_charge'] == 30 + used <= 40
    control = load(new / 'worker-0-controller.json')
    assert sha(Path(control['stdout_path'])) == control['stdout_sha256']
    assert sha(Path(control['stderr_path'])) == control['stderr_sha256']
    assert control['process_group_clean'] and not control['residual_live_pids']
    module_spec = importlib.util.spec_from_file_location('frozen_followup_oracle', new / 'frozen-harness/pilot_grade.py')
    oracle = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(oracle)
    result = trial.get('agent_result') or {}
    error = trial.get('failure') or result.get('error')
    if result.get('completed') is False or result.get('partial') is True:
        error = error or {'agent_completion_state': 'blocked_or_partial'}
    replay = oracle.grade(spec, trial['fixture'], result.get('final_response'),
                         runtime_error=error, messages=result.get('messages'))
    assert replay == trial['grade']
    passed = (replay['passed'] and trial['inputs_unchanged'] and control['exit_code'] == 0
              and not control['timed_out'] and control['process_group_clean'])
    assert int(passed) == summary['passed_trials']
    # A second explicit state witness, independent of the grade function.
    operations = trial['fixture']['ledger']
    if passed:
        apply = [e for e in operations if e['tool'] == 'bench_apply']
        assert len(apply) == 1
        assert apply[0]['result']['status'] == 'outcome_unknown'
        receipts = [e for e in operations if e['tool'] == 'bench_read' and e['args']['query'] == 'receipt']
        assert len(receipts) >= 1 and receipts[-1]['args']['request_id'] == spec['request_id']
        assert operations.index(receipts[-1]) > operations.index(apply[0])
        assert trial['fixture']['state'] == {'balances': {'alice': 24, 'bob': 6}}
        assert trial['fixture']['receipts'][spec['request_id']]['applied_count'] == 1
    messages = transcript(path.parent / 'state.db')
    write(out / 'followup-public-transcript.json', messages)
    total_usage = {}
    for usage in [old_verification['reported_agent_usage_totals'], trial['agent_usage']]:
        for key, value in usage.items():
            if type(value) is int:
                total_usage[key] = total_usage.get(key, 0) + value
    report = {'schema': 'AresLocalModelPilotCloseoutVerificationV1',
        'verified_at': datetime.now(timezone.utc).isoformat(), 'verified': True,
        'original_six_trials': original_rows, 'original_passed': 0, 'original_failed_or_blocked': 6,
        'original_measurement_validity': 'invalidated by nested dispatch overcount; not a model capability estimate',
        'followup_registered_trials': 1, 'followup_passed_trials': int(passed),
        'followup_failed_or_blocked_trials': int(not passed),
        'followup_scheduled_dispatches': used, 'followup_usage': trial['agent_usage'],
        'followup_grade': replay, 'followup_fixture': trial['fixture'],
        'followup_final_output': result.get('final_response'),
        'followup_trial_sha256': sha(path),
        'combined_conservative_budget_charge': 30 + used, 'authorized_call_cap': 40,
        'combined_agent_reported_usage': total_usage,
        'sdk_internal_retries_independently_counted': False,
        'source_revision': before['revision'], 'source_tracked_file_count': before['tracked_file_count'],
        'source_manifest_sha256': before['tracked_manifest_sha256'],
        'source_and_each_frozen_harness_unchanged_during_own_run': True,
        'same_fixture_and_grade_between_attempts': True,
        'all_recorded_process_groups_clean': True,
        'oracle_replayed_from_frozen_harness': True,
        'external_independent_scientific_validation': False,
        'official_deeprsi_score': False, 'full_programme_complete': False,
        'outreach_cancelled': True, 'email_sent': False,
        'no_production_runtime_or_config_edits': True,
        'not_as_shipped_full_runtime': True}
    write(out / 'verification.json', report)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', help='New append-only verification directory')
    args = parser.parse_args()
    execute(args.out)
