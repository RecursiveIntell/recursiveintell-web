"""Raw-artifact reconciliation and separate canonical-oracle replay."""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import xml.etree.ElementTree as ET


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(run_path,out):
    run=Path(run_path)
    summary=json.loads((run/'summary.json').read_text())
    protocol=json.loads((run/'protocol.json').read_text())
    registered=json.loads((run/'registered-cases.json').read_text())
    hashes=json.loads((run/'harness-before.json').read_text())
    after=json.loads((run/'harness-after.json').read_text())
    assert hashes==after
    for name,digest in hashes.items(): assert sha(run/'frozen-harness'/name)==digest
    source_before=json.loads((run/'source-before.json').read_text())
    source_after=json.loads((run/'source-after.json').read_text())
    assert source_before==source_after
    assert source_before['revision']==protocol['source_revision']
    assert len(registered)==6 and len(summary['results'])==6
    assert len({r['case_id'] for r in registered})==6
    assert {(r['spec']['family'],r['spec']['variant']) for r in registered}=={
        (family,variant) for family in ['atomic','recovery','scope'] for variant in range(2)}
    module_spec=importlib.util.spec_from_file_location('frozen_pilot_oracle',run/'frozen-harness/pilot_grade.py')
    oracle=importlib.util.module_from_spec(module_spec); module_spec.loader.exec_module(oracle)
    rows=[]; calls=0; token_totals={}; all_clean=True
    for index,item in enumerate(registered):
        case_id=item['case_id']; spec=item['spec']; row=summary['results'][index]
        assert row['case_id']==case_id
        control=json.loads((run/f'worker-{index}-controller.json').read_text())
        assert sha(Path(control['stdout_path']))==control['stdout_sha256']
        assert sha(Path(control['stderr_path']))==control['stderr_sha256']
        all_clean=all_clean and control['process_group_clean'] and not control['residual_live_pids']
        path=run/case_id/'trial.json'
        if not path.exists():
            assert row['passed'] is False
            rows.append({'case_id':case_id,'family':spec['family'],'variant':spec['variant'],
                         'passed':False,'status':'missing_trial_artifact','controller':control})
            continue
        trial=json.loads(path.read_text()); assert trial['spec']==spec
        assert trial['input_hashes_before']==trial['input_hashes_after']
        for file in ['pilot_worker.py','pilot_fixtures.py','pilot_grade.py']:
            expected=hashes[file]
            bound=[v for k,v in trial['input_hashes_before'].items() if Path(k).name==file]
            assert bound==[expected]
        assert trial['model']=='gpt-6-luna' and trial['provider']=='openai-codex'
        assert trial['effective_fixture_catalog_names']==['bench_apply','bench_read']
        if set(trial['observed_tool_names'])=={'tool_search','tool_describe','tool_call'}:
            assert trial['deferred_bridge_negative_witness']['canary_executed'] is False
            assert 'error' in str(trial['deferred_bridge_negative_witness']['denial_result']).lower()
        used=trial['scheduled_provider_calls']; assert used==len(trial['call_observer']) and 0<=used<=5
        assert all(call['ordinal']==i+1 and call['requested_model']=='gpt-6-luna'
                   for i,call in enumerate(trial['call_observer']))
        calls+=used
        result=trial.get('agent_result') or {}
        error=trial.get('failure') or result.get('error')
        if result.get('completed') is False or result.get('partial') is True:
            error=error or {'agent_completion_state':'blocked_or_partial'}
        replay=oracle.grade(spec,trial['fixture'],result.get('final_response'),
                           runtime_error=error,messages=result.get('messages'))
        if not used or not any(c['returned'] for c in trial['call_observer']):
            replay['passed']=False
            replay['failed_checks'].append('no_observed_returned_provider_execution')
        assert replay==trial['grade']
        passed=(replay['passed'] and trial['inputs_unchanged'] and control['exit_code']==0
                and not control['timed_out'] and control['process_group_clean'])
        assert passed==row['passed']
        usage=trial.get('agent_usage') or {}
        for key,value in usage.items():
            if type(value) is int: token_totals[key]=token_totals.get(key,0)+value
        rows.append({'case_id':case_id,'family':spec['family'],'variant':spec['variant'],
                     'passed':passed,'status':trial['status'],'scheduled_calls':used,
                     'usage':usage,'failed_checks':replay['failed_checks'],
                     'state':trial['fixture']['state'],'ledger_entries':len(trial['fixture']['ledger']),
                     'final_output':result.get('final_response'),'wall_seconds':trial['wall_seconds'],
                     'trial_sha256':sha(path)})
    assert calls==summary['scheduled_provider_calls'] and calls<=30
    passed=sum(row['passed'] for row in rows)
    assert passed==summary['passed_trials'] and 6-passed==summary['failed_or_blocked_trials']
    assert all_clean
    report={'schema':'AresLocalControlledToolPilotVerificationV1',
            'verified_at':datetime.now(timezone.utc).isoformat(),'run':str(run),
            'verified':True,'registered_trials':6,'passed_trials':passed,'failed_or_blocked_trials':6-passed,
            'scheduled_provider_calls':calls,'reported_agent_usage_totals':token_totals,
            'per_trial':rows,'source_revision':source_before['revision'],
            'tracked_source_file_count':source_before['tracked_file_count'],
            'tracked_manifest_sha256':source_before['tracked_manifest_sha256'],
            'source_and_harness_unchanged':True,'all_recorded_process_groups_clean':True,
            'oracle_replayed_from_frozen_harness':True,'raw_log_hashes_reconciled':True,
            'independent_scientific_validation':False,'official_deeprsi_score':False,
            'full_capability_programme_complete':False}
    with Path(out).open('x') as handle:
        json.dump(report,handle,indent=2,sort_keys=True); handle.write('\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('run'); parser.add_argument('--out',required=True)
    args=parser.parse_args(); verify(args.run,args.out)
